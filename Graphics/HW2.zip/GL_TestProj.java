
import java.awt.*;
import java.awt.event.WindowEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.WindowAdapter;

import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.fixedfunc.GLMatrixFunc;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.Animator;



import com.jogamp.opengl.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.jogamp.common.*;

public class GL_TestProj {
	GL_TestProj(){
		GLCanvas canvas = new GLCanvas();
		Animator anim = new Animator(canvas);
		readDatafile readData = new readDatafile();
		readData.getdata();
		color.makedata();
		addCanvasToFrame(canvas,anim,readData.title);
		ShowListener showl = new ShowListener(canvas);
		anim.start();
	}
	List<SavedData> objectdata = new ArrayList<SavedData>(); // save data of sample data file
	int objectnumber;
	coolwarm color = new coolwarm(); // save data of coolwarm
	int snum; // save the value number of sample data file
	int getcolor = 0; // get s value number that wanted to use
	
	// make frame and put canvas on it. Make function for exiting.
	private void addCanvasToFrame( GLCanvas canvas, final Animator anim, String title){
		Frame f = new Frame(title);
		f.setSize(1000,1000);
		f.add(canvas);
		f.setVisible(true);
		f.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				anim.stop();
				System.exit(0);
			}
		});
		
	} 
	
	// class for reading data.
	class readDatafile{
		String title;
		int Varnum;
		
		void getdata(){ // read each data and make decent form and put it.
			try {
				BufferedReader ReadData =new BufferedReader( new FileReader("Sample Data File.txt"));
				String s = ReadData.readLine();
				String [] split = s.split("\"");
				title = split[1];
				s = ReadData.readLine();
				String [] split2 = s.split(",");
				Varnum = split2.length;
				snum = split2.length;
				int nodes;
				int ele;
				int count = 0;
				while((s = ReadData.readLine()) != null)
				{
					count += 1;
					split = s.split(",");
					split2 = split[0].split("\"");
					String title = split2[1];
					split2 = split[1].split("=");
					nodes = Integer.valueOf(split2[1]);
					split2 = split[2].split("=");
					ele = Integer.valueOf(split2[1]);
					SavedData a = new SavedData();
					a.makedata(nodes,ele,title);
					if(Varnum > 4)
					{
						if(Varnum > 9)
						{
							System.out.println("Too many data. value should not be more than 6 except x,y,z");
						}
						else{
							a.makeextradata(nodes, ele);
						}
					}
					
					for(int i = 0; i < nodes; i++)
					{
						s = ReadData.readLine();
						String[] split3,split4;
						split4 = s.split(" ");
						split3 = split4[1].split("E");
						a.nodex[i] = Double.valueOf(split3[0])*Math.pow(10,Double.valueOf(split3[1]));
						split3 = split4[2].split("E");
						a.nodey[i] = Double.valueOf(split3[0])*Math.pow(10,Double.valueOf(split3[1]));
						split3 = split4[3].split("E");
						a.nodez[i] = Double.valueOf(split3[0])*Math.pow(10,Double.valueOf(split3[1]));
						split3 = split4[4].split("E");
						a.nodes[i] = Double.valueOf(split3[0])*Math.pow(10,Double.valueOf(split3[1]));
						if(split4.length == 6)
						{
							split3 = split4[4].split("E");
							a.nodes[i] = Double.valueOf(split3[0])*Math.pow(10,Double.valueOf(split3[1]));
						}
						if(split4.length == 7)
						{
							split3 = split4[4].split("E");
							a.nodes[i] = Double.valueOf(split3[0])*Math.pow(10,Double.valueOf(split3[1]));
						}
						if(split4.length == 8)
						{
							split3 = split4[4].split("E");
							a.nodes[i] = Double.valueOf(split3[0])*Math.pow(10,Double.valueOf(split3[1]));
						}
						if(split4.length == 9)
						{
							split3 = split4[4].split("E");
							a.nodes[i] = Double.valueOf(split3[0])*Math.pow(10,Double.valueOf(split3[1]));
						}
					}
					for(int i = 0; i < ele; i++)
					{
						s = ReadData.readLine();
						split = s.split(" ");
						a.elex[i] = Integer.valueOf(split[1]);
						a.eley[i] = Integer.valueOf(split[2]);
						a.elez[i] = Integer.valueOf(split[3]);
						a.eles[i] = Integer.valueOf(split[4]);
					}
					objectdata.add(a);
				}
				objectnumber=count;
				ReadData.close();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				System.out.println("File Input Error!");
				e1.printStackTrace();
			} catch(IOException e){
				System.out.println("File input Error!");
				System.exit(1);
			}
			
		}		
		
	}
	//class for allocate memory to data.
	class SavedData{
		int nodenum,elenum;
		double [] nodex;
		double [] nodey;
		double [] nodez;
		double [] nodes;
		double [] nodeextras1;
		double [] nodeextras2;
		double [] nodeextras3;
		double [] nodeextras4;
		double [] nodeextras5;
		int [] elex ;
		int [] eley ;
		int [] elez;
		int [] eles ;
		int [] eleextras1;
		int [] eleextras2;
		int [] eleextras3;
		int [] eleextras4;
		int [] eleextras5;
		String title;
		//allocate memory as much it needed
		void makedata(int node, int element, String t){
			elenum = element;
			nodenum = node;
			title = t;
			nodex = new double[node];
			nodey = new double[node];
			nodez = new double[node];
			nodes = new double[node];
			elex = new int[element];
			eley = new int[element];
			elez = new int[element];
			eles = new int[element];
		}
		void makeextradata(int node,int element)
		{
			nodeextras1 = new double[node];
			nodeextras2 = new double[node];
			nodeextras3 = new double[node];
			nodeextras4 = new double[node];

			eleextras1 = new int[element];
			eleextras2 = new int[element];
			eleextras3 = new int[element];
			eleextras4 = new int[element];

		}
	}
	//class for save color data file.
	class coolwarm{
		double [] scalar = new double[257];
		double [] R = new double[257];
		double [] G = new double[257];
		double [] B = new double[257];
		void makedata()
		{
			try {
				BufferedReader Readcolor =new BufferedReader( new FileReader("CoolWarmFloat257.csv"));
				String s;
				s = Readcolor.readLine();
				int count = 0;
				while((s = Readcolor.readLine()) != null)
				{
					
					String [] spl;
					spl = s.split(",");
					scalar[count] = Double.valueOf(spl[0]);
					R[count] = Double.valueOf(spl[1]);
					G[count] = Double.valueOf(spl[2]);
					B[count] = Double.valueOf(spl[3]);
					count +=1;
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("Color File Input Error");
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Color File Input Error");
				e.printStackTrace();
			}
		}
	}
	//method for giving color value to vertex
	public void getcolor(double [] a , GL2 gl, int index)
	{
		int ans=0;
		double max=0,min=100;
		for(int i = 0; i < a.length; i++)
		{
			if( a[i] > max )
			{
				max = a[i];
			}
			if(a[i] < min)
			{
				min = a[i];
			}
		}
		int val = (int)Math.floor(256/(max-min)*(a[index]-min));
		
		
		gl.glColor3d(color.R[val], color.G[val], color.B[val]);
	}
	
	//Drawing Zet. According to (int)getcolor, colors that are put become different.
	// execute getcolor method in here
	public void drawpoly(GL2 gl)
	{
		Iterator<SavedData> it = objectdata.iterator();
		while(it.hasNext())
		{
			SavedData a = it.next();
			
			if(getcolor + 3 > snum )
			{
				getcolor = 0;
			}
			if(getcolor == 0)
			{
				for(int i = 0; i < a.elenum; i++)
				{
				
					gl.glBegin(GL2.GL_LINE_LOOP);
					gl.glColor3f(1, 1, 1);
					gl.glClearColor(0, 0, 0, 1);
					gl.glVertex3d(a.nodex[a.elex[i]-1], a.nodey[a.elex[i]-1], a.nodez[a.elex[i]-1]);
					gl.glVertex3d(a.nodex[a.eley[i]-1], a.nodey[a.eley[i]-1], a.nodez[a.eley[i]-1]);
					gl.glVertex3d(a.nodex[a.elez[i]-1], a.nodey[a.elez[i]-1], a.nodez[a.elez[i]-1]);
					gl.glEnd();
				
				}	
			}
			else
			{
				switch(getcolor)
				{
				case 1:
					for(int i = 0; i < a.elenum; i++)
					{
					
						gl.glBegin(GL2.GL_POLYGON);
					
						getcolor(a.nodes,gl,a.elex[i]-1);
						gl.glVertex3d(a.nodex[a.elex[i]-1], a.nodey[a.elex[i]-1], a.nodez[a.elex[i]-1]);
						
						getcolor(a.nodes,gl,a.eley[i]-1);
						gl.glVertex3d(a.nodex[a.eley[i]-1], a.nodey[a.eley[i]-1], a.nodez[a.eley[i]-1]);
					
						getcolor(a.nodes,gl,a.elez[i]-1);
						gl.glVertex3d(a.nodex[a.elez[i]-1], a.nodey[a.elez[i]-1], a.nodez[a.elez[i]-1]);
						gl.glEnd();
					
					}
					break;
				case 2:
					for(int i = 0; i < a.elenum; i++)
					{
					
						gl.glBegin(GL2.GL_POLYGON);
						
						getcolor(a.nodeextras1,gl,a.elex[i]-1);
						gl.glVertex3d(a.nodex[a.elex[i]-1], a.nodey[a.elex[i]-1], a.nodez[a.elex[i]-1]);
						
						getcolor(a.nodeextras1,gl,a.eley[i]-1);
						gl.glVertex3d(a.nodex[a.eley[i]-1], a.nodey[a.eley[i]-1], a.nodez[a.eley[i]-1]);
					
						getcolor(a.nodeextras1,gl,a.elez[i]-1);
						gl.glVertex3d(a.nodex[a.elez[i]-1], a.nodey[a.elez[i]-1], a.nodez[a.elez[i]-1]);
						gl.glEnd();
					
					}
					break;
				case 3:
					for(int i = 0; i < a.elenum; i++)
					{
					
						gl.glBegin(GL2.GL_POLYGON);
						
						getcolor(a.nodeextras2,gl,a.elex[i]-1);
						gl.glVertex3d(a.nodex[a.elex[i]-1], a.nodey[a.elex[i]-1], a.nodez[a.elex[i]-1]);
						
						getcolor(a.nodeextras2,gl,a.eley[i]-1);
						gl.glVertex3d(a.nodex[a.eley[i]-1], a.nodey[a.eley[i]-1], a.nodez[a.eley[i]-1]);
					
						getcolor(a.nodeextras2,gl,a.elez[i]-1);
						gl.glVertex3d(a.nodex[a.elez[i]-1], a.nodey[a.elez[i]-1], a.nodez[a.elez[i]-1]);
						gl.glEnd();
					
					}
					break;
				case 4:
					for(int i = 0; i < a.elenum; i++)
					{
					
						gl.glBegin(GL2.GL_POLYGON);
						
						getcolor(a.nodeextras3,gl,a.elex[i]-1);
						gl.glVertex3d(a.nodex[a.elex[i]-1], a.nodey[a.elex[i]-1], a.nodez[a.elex[i]-1]);
						
						getcolor(a.nodeextras3,gl,a.eley[i]-1);
						gl.glVertex3d(a.nodex[a.eley[i]-1], a.nodey[a.eley[i]-1], a.nodez[a.eley[i]-1]);
					
						getcolor(a.nodeextras3,gl,a.elez[i]-1);
						gl.glVertex3d(a.nodex[a.elez[i]-1], a.nodey[a.elez[i]-1], a.nodez[a.elez[i]-1]);
						gl.glEnd();
					
					}
					break;
				case 5:
					for(int i = 0; i < a.elenum; i++)
					{
					
						gl.glBegin(GL2.GL_POLYGON);
						
						getcolor(a.nodeextras4,gl,a.elex[i]-1);
						gl.glVertex3d(a.nodex[a.elex[i]-1], a.nodey[a.elex[i]-1], a.nodez[a.elex[i]-1]);
						
						getcolor(a.nodeextras4,gl,a.eley[i]-1);
						gl.glVertex3d(a.nodex[a.eley[i]-1], a.nodey[a.eley[i]-1], a.nodez[a.eley[i]-1]);
					
						getcolor(a.nodeextras4,gl,a.elez[i]-1);
						gl.glVertex3d(a.nodex[a.elez[i]-1], a.nodey[a.elez[i]-1], a.nodez[a.elez[i]-1]);
						gl.glEnd();
					
					}
					break;
				}
			}	
		}
	}
	public static void main(String args[]) {
		new GL_TestProj();
	}
	
	//All eventListener for executing JOGL
	class ShowListener implements GLEventListener,MouseListener,MouseMotionListener,KeyListener{
		GL2 gl;
		float saveangle=0;
		int mousemoved;
		float angle = 0;
		float anglex,angley;
		int projection = 0;
		int rotation = 0;
		int freerotation = 0;
		
		//using these value, make keyboard and mouse working with canvas.
		private final GLCanvas canvas;
		public ShowListener(GLCanvas canvas)
		{
			this.canvas = canvas;
			
			canvas.addGLEventListener(this);
			canvas.addMouseListener(this);
			canvas.addMouseMotionListener(this);
			canvas.addKeyListener(this);
		}
		//initialize
		public void init(GLAutoDrawable drawable){
			gl =  drawable.getGL().getGL2();
			gl.glClearColor(0, 0, 0, 1);
			gl.glColor3f(0,0,0);
			gl.glShadeModel(GL2.GL_SMOOTH);
			gl.glClearDepthf(1.0f);
			gl.glEnable(GL2.GL_DEPTH_TEST);
			gl.glDepthFunc(GL2.GL_LEQUAL);
			gl.glHint(GL2.GL_PERSPECTIVE_CORRECTION_HINT,GL2.GL_NICEST);
			gl.glClear( GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT );
			GLU glu = new GLU();
			gl.glLoadIdentity();
			anglex=0;
			angley=0;
		}
		@Override
		public void display(GLAutoDrawable arg0){
			gl = arg0.getGL().getGL2();
			GLU glu = new GLU();
			gl.glLoadIdentity();
			gl.glMatrixMode(GL2.GL_MODELVIEW);
			
			if(projection == 1) // projection variable becomes 1 when it get 'o' from keyboard
			{
				gl.glOrtho(-30, 30, -30, 30, 30, -30);
			}
			gl.glClearColor(0, 0, 0, 1);
			gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
			if(mousemoved == 1) // mousemoved variable becomes 1 when mouseDragged is on
			{
				gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
				
				gl.glLoadIdentity();
				if(projection == 1)
				{
					gl.glOrtho(-30, 30, -30, 30, 30, -30);
				}
				//rotation 0 : normal condition
				//rotation 1 : when keyboard is put z
				//rotation 2 : when keyboard is put x
				//rotation 3 : when keyboard is put c
				if(rotation == 0){
					gl.glTranslatef(-anglex/30,0, anglex/1000);
					
					gl.glTranslatef(0, angley/30, -angley/1000);
				}
				else if(rotation == 1)
				{
					gl.glRotatef(angle, 1, 1, 0);
				}
				else if(rotation == 2)
				{
					gl.glRotatef(angle, 0, 1, 1);
				}
				else if(rotation == 3)
				{
					gl.glRotatef(angle, 1, 0, 1);
				}
				//when keyboard is put r
				if(freerotation == 1)
				{
					freerot(gl);
				}
				gl.glRotatef(saveangle/10, 1, 1, 1);
				//method that draws object
				drawpoly(gl);
			}
		
			else
			{
				//when mouse is not dragged
				if(rotation == 0){
					gl.glTranslatef(-anglex/30,0, anglex/200);
					gl.glTranslatef(0, angley/30, -angley/200);
				}
				gl.glRotatef(saveangle/10, 1, 1, 1);
				drawpoly(gl);
			}
			
		}
		public void freerot(GL2 gl)
		{
			saveangle = angle;
		}
		@Override
		public void dispose(GLAutoDrawable arg0) {}
		@Override
		public void reshape(GLAutoDrawable arg0, int arg1, int arg2, int arg3, int arg4){}
		//variables for mouse control.
		int pMousex = 0;
		int pMousey = 0;
		@Override
		//when mouseDragged, give values some variables so that can control rotating and moving of object 
		public void mouseDragged(MouseEvent arg0) {
			
			int newMousex=arg0.getX();
			int newMousey=arg0.getY();
			if(pMousex == 0)
			{
				pMousex = newMousex;
			}
			else if(pMousex != newMousex)
			{
				
				mousemoved = 1;
				angle += pMousex - newMousex;
				anglex += pMousex - newMousex;
				pMousex = newMousex;
			}
			
			if(pMousey == 0)
			{
				pMousey = newMousey;
			}
			else if(pMousey != newMousey)
			{
				mousemoved = 1;
				angle += pMousey - newMousey;
				angley += pMousey - newMousey;
				pMousey = newMousey;	
			}
		}
		@Override
		public void mouseMoved(MouseEvent arg0) {}
		@Override
		public void mouseClicked(MouseEvent arg0) {}
		@Override
		public void mouseEntered(MouseEvent arg0) {}
		@Override
		public void mouseExited(MouseEvent arg0) {}
		@Override
		public void mousePressed(MouseEvent arg0) {}
		@Override
		//when dragging is over, initialize variables that needed to be initialized
		public void mouseReleased(MouseEvent arg0) {
			mousemoved = 0;
			angle = 0;
		}
		@Override
		//make commands that can be worked through keyboard
		public void keyPressed(KeyEvent arg0) {
			// TODO Auto-generated method stub
			int key = arg0.getKeyCode();

			if(key == KeyEvent.VK_1)
			{
				getcolor = 0;
			}
			else if(key == KeyEvent.VK_2)
			{
				getcolor = 1;
			}
			else if(key == KeyEvent.VK_3)
			{
				getcolor = 2;
			}
			else if(key == KeyEvent.VK_4)
			{
				getcolor = 3;
			}
			else if(key == KeyEvent.VK_5)
			{
				getcolor = 4;
			}
			else if(key == KeyEvent.VK_6)
			{
				getcolor = 5;
			}
			if(key == KeyEvent.VK_P)
			{
				projection = 0;
			}
			else if(key == KeyEvent.VK_O)
			{
				projection = 1;
			}
			if(key == KeyEvent.VK_Z)
			{
				//z axis rotation
				rotation = 1;
			}
			else if(key == KeyEvent.VK_X)
			{
				//x axis rotation
				rotation = 2;
			}
			else if(key == KeyEvent.VK_C)
			{
				//y axis rotation
				rotation = 3;
			}
			if(key == KeyEvent.VK_R)
			{
				freerotation = 1;
			}
		}
		//initialize after job with keyboards done.
		@Override
		public void keyReleased(KeyEvent arg0) {
			// TODO Auto-generated method stub
			int key = arg0.getKeyCode();
			if(key == KeyEvent.VK_Z)
			{
				//z axis rotation
				rotation = 0;
			}
			else if(key == KeyEvent.VK_X)
			{
				//x axis rotation
				rotation = 0;	
			}
			else if(key == KeyEvent.VK_C)
			{
				//y axis rotation
				rotation = 0;
			}
			else if(key == KeyEvent.VK_R)
			{
				freerotation = 0;
			}
		}
		@Override
		public void keyTyped(KeyEvent arg0) {}
	}
}