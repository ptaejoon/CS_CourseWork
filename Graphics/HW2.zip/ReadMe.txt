Included code is for JOGL environment graphic work.

In order to execute it, put this code in project that has JOGL environment.

In basic condition, It's on perspective projection, with wireframe structure. If you feel awkward with perspective porjection, press O to see with Orthogonal projection.

In order to execute the program, program needs two data file within same project:

1. Sample Data File.txt (Value of Graphic data that you want to see in program)

2. CoolWarmFloat257.csv for coloring

Concerned with 1. Sample Data File.txt....

This program can get 4 more s value of nodes.
Then file format should be different, like
x y z s extra_s1 extra_s2 extra_s3 extra_s4

However, you can also put 8 value in a line of elements, but program will only accept first 3 values of a line.


This program has following commands, and some of them needs keyboard input.


O : Change projection as Orthogonal projection.
P : Change projection as Perspective projection.

1 (Keynumber) : show object with wireframe.
2 : show object with polygons with s-color.
3 : show object with polygons with extra s1 color. If you didn't add this value, this key act as command 1 do.
4 : show object with polygons with extra s2 color. If you didn't add this value, this key act as command 1 do.
5 : show object with polygons with extra s3 color. If you didn't add this value, this key act as command 1 do.
6 : show object with polygons with extra s4 color. If you didn't add this value, this key act as command 1 do.


Moving mouse : Translation of object
Moving mouse with pressing z : Rotating around z-axis.
Moving mouse with pressing x : Rotating around x-axis.
Moving mouse with pressing c : Rotating around y-axis.

Moving mouse with pressing r : Free rotating.