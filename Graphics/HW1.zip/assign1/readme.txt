This text file explains how to use this program.

Open Processing file 'assign1' and press Ctrl+R. Then it will automatically show graph.

If you want to change size of graph, go to the line 114 in the Processing file, and revise the number as you want.
First number is length of X, next one is length of Y.

The data file you want to use must be named as "Assignment1-Sample.csv".
If you don't want to change data file's name, Then go to line 33 and change it's file name.

However, contents of data file must follow this rules.
At first line, It must be name of values like "date,Low,Open,Close,High". And also should follow same order.
If you put your data at first line, program will not detect it.
And, each data much be seperated by space. Otherwise, do not use space.
Concerned with date, seperate day,month,year with character '/'

Default size of this program is (1400,800)
It is highly recommended to use same ratio.
However, if size become lower than 300, it is easy to make error in graph.
Using big number for size is recommended

Screenshots saved in zip file show same data's graph with different size.