//Name : Park Tae-Joon
//Student ID : 28128044
//start date : 26/August/2016
//last modified date : 2/September/2016
//This program deals with CLI plus additional commands new,cp,find,run and halt. While loop in main function acts as command line. It waits until get executable command and keep working until it get 'quit' command.
//

#include<stdio.h>
#include<syscall.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<dirent.h>
#include<signal.h>

void main()
{
	int i,j; // Counter for 'for' loop
	char command[200]; // get command
	char *command_split;
	char *command_after;
	char *command_error; // these three char * used to use seperated command's word.
	char *new_file; 
	char get_enter; // In pause command. To check whether user press enter or not.
	char dirname[200]; // Save present file address
	struct dirent* whats_in_dir; // In dir and cp commands. To check files in directory
	DIR *fileinfo; // In dir and cp commands. To open directory.
	FILE *fp;
	FILE *oldfile; 
	FILE *newfile; // In cp, file pointers to open files.
	char copyword=1; // In cp, to copy the contents of old files
	pid_t pid[2]; // to make child processor
	int find_avail=0; // In find, to check whether find is executable or not
	int copy_avail=0; // In cp, to check whether cp is executable or not
	char copy_name[200]; // In cp, to copy new file's name 
	char find_string[2000]; // In cp, to copy find's file name
	int find_counter=0; // counter used in find
	int ch_long; // In find, To check whether word is exist or not 
	int run_avail; // To check run is available or not
	 
	int process_counter = 0; // In pause, to use two process
	int for_wait; // used to function wait

	//this infinite loop works as CLI
	while(1)
	{
	    getcwd(dirname,199); // get present address of file.
	   
	    //------------------------------------------------------------- 
	    printf("$");
	    // this character will work as special prompt character.
	    //--------------------------------------------------------------
	    
	    //get command.------------------------------------------------
	    gets(command);
	    //---------------------------------------------------------
	    
	    
	    //check whether command is put or not-----------------------------
	    if(command[0] == '\0')
	    {
		continue; // if there's no command, just restart while loop.
	    }
	    //------------------------------------------------


	    //command_split will get command that user wants to execute.
	    command_split = strtok(command," ");
	    //--------------------------------------------------------
	  
	    //execute clear command when "clear" is put--------------------------
	    if(strcmp(command,"clear")==0)
	    {
		
		
		//clear screen with enter
		for(i=0; i< 300; i++)
		{
			printf("\n");
		}
		//need to cursor situated upside of screen 
		//I found this words in clear command in Unix. If i print it, cursor will go up to top of screen
		printf("[H[2J");
		
		continue;
		//when work is done, go back to while loop
	    }
	    //-------------------------------------------------------------------

	    
	    //execute quit command -----------------------------------------------------------
	    else if(strcmp(command_split,"quit")==0)
	    {
		command_error = strtok(NULL," ");
		if(command_error != NULL)
		{
		    printf("quit : cannot execute command. Too many arguments\n");
		    continue;
		}
		//If there is another word after 'quit', program will print error message.
		 break;
		 //So infinite loop will break when command is exactly "quit"
	    }
	    //--------------------------------------------------


	    //execute echo command-----------------------------------------------------------
	    else if(strcmp(command_split,"echo")==0)
	    {
		//In Unix, echo works even there's no '"', and don't care about space. so I follwed same way
		command_after=strtok(NULL,"\"");
		//use " as seperator so that " will not be printed.
		while(command_after != NULL){
		    printf("%s",command_after);
		    command_after = strtok(NULL,"\"");
		}
		// print all words
		printf("\n");
		continue;
	    }
	    //---------------------------------------------------------------------------------

	    //execute help command----------------------------------------------------
	    else if(strcmp(command_split,"help")==0)
	    {
		command_after = strtok(NULL," ");
		if(command_after != NULL)
		{
		    printf("help : cannot execute file. Too many arguments\n");
		    continue;
		}
		//make command execute when only 'help' is quit.
		pid[0] = fork();
		if(pid[0] == 0)
		{
		    execl("/bin/more", "/bin/more","help_task2.txt",NULL);
		}
		else if(pid[0] > 0)
		{
			wait(&for_wait); // wait until child process is done
			continue;
		}
		
		//execute more using execl with already made text file of help.
	    }
	    //--------------------------------------------------------------------------------

	    //execute pause command -----------------------------------------------------------
	    else if(strcmp(command_split,"pause")==0)
	    {
		//Pause the execution of CLI program until the Enter key is pressed
		while(process_counter < 2)
		{

		pid[process_counter] = fork();
		if(pid[process_counter] == 0)
		{
		    if(process_counter == 0)
		    {	

		    	execl("/bin/stty", "/bin/stty","-echo",NULL);
			//first child process : set terminal not to show inputs through keyboard
		 }
		    if(process_counter == 1)
		    {
			
			while(1)
			{
			    scanf("%c",&get_enter);
			    if(get_enter == '\n')
			    {
				break;
			    }
			}

			execl("/bin/stty","/bin/stty","echo",NULL);
		    }
		    	//second child process : wait until get enter and set terminal's condition back.

			
		}
		else if(pid[process_counter] > 0)
		{
		    if(process_counter == 0)
		    {
			wait(&for_wait);
			process_counter =1; // wait child process
		    }
		    else if(process_counter == 1)
		    {
			process_counter = 2;
			wait(&for_wait); // wait child process
		    }
		}
		}
		process_counter = 0;
	    }

	    //------------------------------------------------------------------------------


	    //execute dir command ---------------------------------------------------
	    else if(strcmp(command_split,"dir")==0)
	    {

		command_after = strtok(NULL," ");
		if(command_after == NULL)//if there's no command after dir, command should execute to present directory.
		{
		   //show present directory
			fileinfo=opendir("."); // open present file.
			if(fileinfo != NULL)
			{
			    while(whats_in_dir = readdir( fileinfo)) // read each file in directory.
			    {
				printf("%s	", whats_in_dir->d_name); 
			    }
			    closedir(fileinfo);//close file
			    printf("\n");
			    continue;
			}
			else
			{
			    printf("\n");
			    closedir(fileinfo);
			    continue;
			}
			//if present file is empty, jsut print enter.
		}
		else // need to go specific directory and search what files are inside.
		{
		    while(command_after != NULL)
		    {
			fileinfo=opendir(command_after);
			//open specific file, but if there's no such directory, show error message
			if(fileinfo == NULL)
			{
			    printf("dir : cannot access '%s' : No such file or directory\n",command_after);
			    closedir(fileinfo);
			
			}
			else
			{
			    printf("%s:\n",command_after);
			    while(whats_in_dir = readdir(fileinfo))
			    {
				printf("%s	",whats_in_dir->d_name);
			    }
			    closedir(fileinfo);
			    printf("\n");
			}
			command_after = strtok(NULL," ");
		    }
		}
	    }
	    //------------------------------------------------------------------


	    //execute cd command---------------------------------------------------------------
	    else if(strcmp(command_split,"cd")==0)
	    {
		command_after = strtok(NULL," ");
		if(command_after == NULL) // if there's nothing after cd, move to home directory
		{

		    chdir("/home");//change directory to home
		    continue;
		}
		else // move to specific directory.
		{
		  while(command_after != NULL)
		  {
			// if anything among keywords have file, go there.
		      if(strcmp(command_after,"~") == 0)//if directory is "~", it means go to home directory.
		      {
			  chdir("/home");
			  break;
		      }
		      if(chdir(command_after)==0) // chdir return 0 when it succeed to move directory
		      {
			  break;
		      }
		      command_after = strtok(NULL," ");

		  }
		  if(command_after != NULL)
		  {
		      continue;
		  }
		  printf("cd: cannot execute command. Have no such directory or file\n");
		  continue;
		}
	    }
		//-------------------------------------------------------------------------i

	    //execute new command ------------------------------------------------------------
	    else if(strcmp(command_split,"new") == 0)
	    {
		//create a neww fill with name <file>
		command_after = strtok(NULL," ");

		command_error = strtok(NULL," ");
		if(command_error != NULL)
		{
		    printf("new: cannot execute command. Too many arguments.\n");
		    continue;
		}
		// if there's more keyword after <file>, return error message
		else
		{
			if(command_after == NULL)
			{
			    printf("new : cannot execute command. No name argument.\n");
			    continue;
			}
			//if there's no <file>, return error message
			else
			{
	
				fp=fopen(command_after,"w");
			
				fclose(fp);
			}
			//make new file by opening with named <file> and closing it.
		}
	    }
	    //-----------------------------------------------------------------------

	    //execute cp command------------------------------------------------------
	    else if(strcmp(command_split,"cp")==0)
	    {
		//cp <old> <new> copy. if old dont exist, error
		command_after = strtok(NULL," ");
		new_file = strtok(NULL," ");
		if(command_after == NULL || new_file == NULL)
		{
		    printf("cp : cannot execute command. Too few arguments. \n");
		    continue;
		} // if there's no <old> or <new> arguments, show error message.
		fileinfo = opendir(".");
		//open present directory.
		if(fileinfo != NULL)
		{
			while(whats_in_dir = readdir(fileinfo)) // read whole files in directory
			{
				if(strcmp(command_after,whats_in_dir->d_name)==0)
				{
					copy_avail = 1;
					strcpy(copy_name,whats_in_dir->d_name);
					break;
				}
				//if there's file has same name with <old>, copy <old>'s name to copy_name;
			}
			closedir(fileinfo);
			//close directory.

			if(strcmp(copy_name,new_file) == 0)
			{
			   printf("cp : cannot execute command. Cannot copy as same name");
			   copy_avail = 0;
			   continue;
			}
			//if <old> and <new> have same name, show error message.


			else if(copy_avail == 1)
			{
			    oldfile = fopen(command_after,"r");
			    newfile = fopen(new_file,"at");
			    while(!feof(oldfile)) // get every character in file until the end of file.
			    {
				copyword=fgetc(oldfile);
				fprintf(newfile,"%c",copyword);
			    }
			    fclose(oldfile);
			    fclose(newfile);
			    copy_avail = 0;
			    copyword = 1;
			    continue;
			}
			//if copy_avail = 1, copy file.


			else if(copy_avail == 0)
			{
			    printf("cp : cannot execute command. No such file or directory. \n");
			    continue;
			}
			//if copy_avail = 0, show error message
		}
		else
		{
			printf("cp: cannot execute command. No such file to copy. \n");
			continue;
		}
		//if present directory is empty, show error message.
		
	    }
	    //------------------------------------------------------

	    //execute find command ---------------------------------------------------------
	    else if(strcmp(command_split,"find")==0)
	    {
		
		command_after = strtok(NULL," "); // get <char>
		command_error = strtok(NULL," "); // get <file>
		if(command_after == NULL || command_error == NULL)
		{
		    printf("find : cannot execute command. Too few arguments. \n");
		    continue;
		}
		//if one of <char> or <file> has no value, return error message
		else
		{
			fileinfo=opendir(".");
			//open present directory
			if(fileinfo != NULL)
			{
			    while(whats_in_dir = readdir(fileinfo))
			    {
				if(strcmp(whats_in_dir->d_name,command_error)==0)
				{
				    find_avail=1;
				    strcpy(copy_name,whats_in_dir->d_name);
				    break;
				}
			    }
			}
			//find if there is file that named <file>. if it is, find_avail become 1
			closedir(fileinfo);
			//close present directory
			if(find_avail == 1)
			{
			    
			   newfile=fopen(copy_name,"r");
			   
			//since there was no exact explanation of <char>, I made this command even can find the number of occurence of word as well as a single character.
			   while(!feof(newfile))
			   {
			       fgets(find_string,1999,newfile);
			       
			       ch_long = strlen(command_after);

				for(j=0;j<strlen(find_string);j++)
				{
				    if(find_string[j] == command_after[0])
				    {
					for(i=0;i<ch_long;i++)
					{
					    if(find_string[j+i] != command_after[i])
					    {
						break;
					    }
					    else if(i == ch_long-1)
					    {
						find_counter++;
					    }
					}
				    }
				}
				//using this loop, check the existence of <char>
				
			   }

			    printf("number of occurrence : %d\n",find_counter);
			    find_avail=0; //find_string ch_long;
			    find_counter = 0;
			    fclose(newfile);
				continue;
			}
			else
			{
				printf("find : cannot exexcute command. No such file. \n");
				continue;
			}
			//when find_avail = 0, it means there's no such file called <file>

		}

	   	 
	    }
	    //-------------------------------------------------------------------------

	    //execute run command---------------------------------------------
	    else if(strcmp(command_split, "run")==0)
	    {
		command_after = strtok(NULL," ");
		command_error = strtok(NULL," ");
		if(command_error != NULL)
		{
		    printf("run : cannot execute command. Too many arguments. \n");
		    continue;
		}// if there more keyword after <program>, show error message
		if(command_after == NULL)
		{
		    printf("run : cannot execute command. Too few arguments. \n");
		    continue;
		} // if there's no <program>, show error message
		else
		{
		  
				pid[0] = fork();
				//make new process since execl terminate itself when the function execute another program.
				if(pid[0] == 0)
				{
				    
				    execl(command_after,command_after,NULL);
				    printf("run : cannot execute command. There's no such file. Try with exact directory\n");
					break;
				    
				}
				//when is child process
				if(pid[0] >0)
				{
				   // wait until child process is done.
				    continue;
				}
				//when is parent process


			    }
			

		    
		
	
	    }
	    //-------------------------------------------------------------------------

	    //execute halt command -----------------------------------------------------
	    else if(strcmp(command_split,"halt")==0)
	    {
		command_after = strtok(NULL," ");
		command_error = strtok(NULL," ");
		if(command_error != NULL)
		{
		    printf("halt : cannot execute command. Too many arguments\n");
		    continue;
		}
		
		pid[0] = fork();
		if(pid[0] == 0)
		{
		    execl("/usr/bin/killall", "/usr/bin/killall","-9",command_after,NULL);
		   
		}
		else if(pid > 0)
		{
			wait(&for_wait);
			continue;
		}

	    }
	    //------------------------------------------------------------------

	    //in case of wrong command.
	    else
	    {
		printf("Wrong command\n");
	    }

	}
}



