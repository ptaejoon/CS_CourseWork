//Name : Park Tae-Joon
//Student ID : 28128044
//start date : 26/August/2016
//last modified date : 2/September/2016
//This program deals with basic CLI. This program can run command clear,cd,dir,echo,help,pause, and quit. While loop in main function acts as command line. It waits until get executable command and keep working until it get 'quit' command.
//
#include<stdio.h>
#include<syscall.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<dirent.h>

void main()
{
	int i; // In clear command. Just for counting in 'for' loop
	char command[200]; // get command
	
	char *command_split; 
	char *command_after;
	char *command_error; // these three char * used to use seperated command's word.
	char get_enter; // In pause command. To check whether user press enter or not
	char dirname[200]; // Save present file address
	struct dirent* whats_in_dir; // In dir and cp commands. To check files in directory
	DIR *fileinfo; // In dir and cp commands. To open directory.
	pid_t pid[2];
	int for_wait;
	int process_counter = 0;
	
	//this infinite loop works as CLI
	while(1)
	{
	    getcwd(dirname,199); // get present address of file.
	   
	    //-----------------------------------------------------------
	    printf("$");
	    //this character will works as special prompt character.
	    //--------------------------------------------------------


	    //get command.--------------------------------------------------------
	    gets(command);
	    //-----------------------------------------------------------------


	    //check whether command is put or not------------------
	    if(command[0] == '\0')
	    {
		continue; // if there's no command, just restart while loop.
	    }
	    //----------------------------------------------------
	   
	    //command_split will get command that user wants to execute.
	    command_split = strtok(command," ");
	    //--------------------------------------------------
	  
	    //execute clear command when "clear" is put----------------
	    if(strcmp(command,"clear")==0)
	    {
		
		
		//clear screen with enter
		for(i=0; i< 300; i++)
		{
			printf("\n");
		}
		//need to cursor located upside of screen 
		//I found this words in clear command in Unix. If i print it, cursor will go up to top of screen
		printf("[H[2J");
		
		
		continue; 
		// when work is done, go back to while loop
	    }
	    //-----------------------------------------------------


	    //execute quit command --------------------------------
	    else if(strcmp(command_split,"quit")==0) 
	    {
		command_error = strtok(NULL," ");
		if(command_error != NULL)
		{
		    printf("quit : cannot execute command. Too many arguments\n");
		    continue;
		}
		//If there is another word after 'quit', program will print error message.
		
		 break;
		 //So infinite loop will break when command is exactly "quit"
	    }
	    //-----------------------------------------------------
	    
	    
	    //execute echo command --------------------------------------
	    else if(strcmp(command_split,"echo")==0)
	    {
		//In Unix, echo works even there's no '"', and don't care about space. so I followed same way
		command_after=strtok(NULL,"\"");
		//use " as seperator so that " will not be printed.
		while(command_after != NULL){
		    printf("%s",command_after);
		    command_after = strtok(NULL,"\"");
		}
		// print all words
		printf("\n");
		continue;
	    }
	    //-------------------------------------------------------------

	    //execute help command---------------------------------------
	    else if(strcmp(command_split,"help")==0)
	    {
		command_after = strtok(NULL," ");
		if(command_after != NULL)
		{
		    printf("help : cannot execute file. Too many arguments\n");
		    continue;
		}
		//make command execute when only 'help' is put.
		pid[0] = fork();
		if(pid[0] == 0)
		{
		    execl("/bin/more", "/bin/more","help_task1.txt",NULL);
		}
		else if(pid[0] > 0)
		{
		    wait(&for_wait);
		continue;
		}
		//execute more using execl with already made text file of help.
	    }
	    //--------------------------------------------------------

	    //execute pause command ---------------------------------
	    else if(strcmp(command_split,"pause")==0)
	    {
		//Pause the execution of CLI program until the Enter key is pressed
		while(process_counter < 2)
		{
		    

		   	pid[process_counter] = fork();
			if(pid[process_counter] == 0)
			{
			    if(process_counter == 0)
			    {
				execl("/bin/stty", "/bin/stty","-echo",NULL);
			    }
			    if(process_counter == 1)
			    {
				while(1)
				{
				    scanf("%c",&get_enter);
				    if(get_enter == '\n')
			    		break;
				}
				execl("/bin/stty", "/bin/stty","echo",NULL);
			    }
			}
			else if(pid[process_counter] > 0)
			{
			    if(process_counter == 0)
			    {
				wait(&for_wait);
				process_counter = 1;
			    }
			    else if(process_counter == 1)
			    {
				process_counter = 2;
				wait(&for_wait);
			    }
			}
		}
		    process_counter=0;
	
		
	    }
	   //-----------------------------------------------------------

	    //execute dir command------------------------
	    else if(strcmp(command_split,"dir")==0)
	    {

		command_after = strtok(NULL," "); 
		if(command_after == NULL) //if there's no command after dir, command should execute to present directory.
		{
		   //show present directory
			fileinfo=opendir("."); // open present file.
			if(fileinfo != NULL)
			{
			    while(whats_in_dir = readdir( fileinfo)) //read each file in directory
			    {
				printf("%s	", whats_in_dir->d_name);
			    }
			    closedir(fileinfo); // close file
			    printf("\n");
			    continue;
			}
			else
			{
			    printf("\n");
			    closedir(fileinfo);
			    continue;
			} 
			// if present file is empty, just print enter.
		}
		else // need to go specific directory and search what files are inside.
		{
		    while(command_after != NULL)
		    {
			fileinfo=opendir(command_after);
			//open specific file, but if there's no such directory, show error message
			if(fileinfo == NULL)
			{
			    printf("dir : cannot access '%s' : No such directory\n",command_after);
			    closedir(fileinfo);
			
			}
			else
			{
			    printf("%s:\n",command_after);
			    while(whats_in_dir = readdir(fileinfo))
			    {
				printf("%s	",whats_in_dir->d_name);
			    }
			    closedir(fileinfo);
			    printf("\n");
			}
			command_after = strtok(NULL," ");
		    }
		}
	    }
	//----------------------------

	    //execute cd command -----------------------------------------------
	    else if(strcmp(command_split,"cd")==0)
	    {
		command_after = strtok(NULL," ");
		if(command_after == NULL) // if there's nothing after cd, move to home directory.
		{
		    chdir("/home");  //change directory to home
		    continue;
		}
		else // move to specific directory.
		{
		  while(command_after != NULL)
		  {
			// if anything among keyword have file, go there.
		      if(strcmp(command_after,"~") == 0) // if directory is "~", it means go to home directory.
		      {
			  chdir("/home");
			  break;
		      }
		      if(chdir(command_after)==0) // chdir return 0 when it succeed to move directory
		      {
			  break;
		      }
		      command_after = strtok(NULL," ");
		  }
		  if(command_after != NULL)
		  {
		      continue;
		  }
		  printf("cd: cannot execute command. Have no such directory \n");
		  continue;
		}
	    }
	    //------------------------------------------------------------------

	    //in case of wrong command.
	    else
	    {
		printf("Wrong command\n");
	    }

	}
}



