#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>

typedef struct pr{
	char PID[100];
	int Artime;
	int Protime;
	int finish;
	int Wtime;
	int Ttime;
}Process;
void main(int argc, char* argv[])
{
	if(argc != 2)
	{
	    return;
	}
	FILE *fp;
	fp = fopen(argv[1],"r");
	Process pro[1000];
	Process cppro[1000];
	int howmany;
	int count = 0;
	char PidRead[100];
	char* str;
	int pronow=0;
	while(1)
	{
	   if(fgets(PidRead,100,fp) == NULL)
	   {
	       break;
	   }
	   str = strtok(PidRead,"	");
	   strcpy(pro[count].PID, str);
	   str = strtok(NULL,"	");
	   pro[count].Artime = atoi(str);
	   str = strtok(NULL,"	"); 
	   pro[count].Protime = atoi(str);
	   pro[count].finish = 0;
	   pro[count].Wtime = 0;
	   pro[count].Ttime = 0;
	   cppro[count] = pro[count];
	   count+=1;
	}
	howmany = count;
	fclose(fp);
	int a,b;
	Process temp;
	count = 0;
	for(a = 0; a < howmany-1; a++)
	{
		for(b = 0; b < howmany-1-a; b++)
		{
			if(pro[b].Artime > pro[b+1].Artime)
			{
				temp = pro[b];
				pro[b] = pro[b+1];
				pro[b+1] = temp;
			}
		}
	}

	int endcounter = 0;
	int arrnum = 0;
	int temp2 = 10000;
	int c=0,d=0;
	while (1)
	{
		temp2 = 10000;
		for (a = 0; a < howmany; a++)
		{
			if (pro[a].finish == 0)
				break;
			if (pro[a].finish == 1 && a == howmany - 1)
			{
				endcounter = 1;
			}
		}

		if (endcounter == 1)
		{
			break;
		}

		for (a = 0; a < howmany; a++)
		{
			if (pro[a].Artime == 0)
			{
				arrnum += 1;
			}
		}
		for (b = 0; b < arrnum; b++)
		{
			if (pro[b].Protime < temp2)
			{
				if (pro[b].Protime != 0)
				{
					temp2 = pro[b].Protime;
					pronow = b;
				}
			}

		}
		pro[pronow].Protime -= 1;
		if (pro[pronow].Protime == 0)
		{
			pro[pronow].finish = 1;

		}

		arrnum = 0;



		for (a = 0; a < howmany; a++)
		{
			if (pro[a].Artime > 0)
			{
				pro[a].Artime -= 1;
			}
			if (pro[a].Artime == 0 && pro[a].finish != 1)
			{
				if (pronow != a)
				{
					pro[a].Wtime += 1;
				}
			}
		}

		printf("%d second : ", count + 1);
		for (a = 0; a < howmany; a++)
		{
			if (pro[a].Protime == 0)
			{
				printf("%s ", pro[a].PID);
				d++;
			}
		}
		printf("\n");

		count++;

	}
	c=count+1-pro[0].Artime;
	float tWtime=0;
	float tTtime=0;
	printf("\n");
	for(a = 0; a<howmany; a++)
	{
	    printf("%s's waiting time : %d seconds \n",pro[a].PID,pro[a].Wtime);
	}
	printf("\n");
	for(a = 0; a<howmany; a++)
	{
	    printf("%s's turnaround time : %d seconds \n",pro[a].PID,pro[a].Wtime+cppro[a].Protime);
	}
	printf("\n");
	for(a = 0; a<howmany; a++)
	{
	    tWtime += pro[a].Wtime;
	    tTtime += pro[a].Wtime+cppro[a].Protime;
	}
	printf("Average waiting time : %.2f seconds \n",tWtime/howmany);
	printf("Average turnaround time : %.2f seconds \n",tTtime/howmany);
	printf("throughput : %.2f \n",(float)d/c);

}

