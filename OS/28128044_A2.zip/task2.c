#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<time.h>
int permutation(char*,int);
void make_process(char **,int);
void main()
{
	char **string;
	int n;
	int i;
	printf("How many string you want to use? : ");
	scanf("%d",&n);
	// since we need to check many string, I allocated dynamic memory to string.
	getc(stdin);
	string = (char **)malloc(sizeof(char *) * n);
	for(i = 0; i < n; i++)
	{
	    string[i] = (char *)malloc(sizeof(char ) * 50);
	    printf("Write string : ");
	    gets(string[i]);
	}
	// start function that create processes that permutate each string.
	make_process(string,n);
	
	for(i=0; i< n; i++)
	{
	    free(string[i]);
	}
	free(string);
}
void make_process(char **string, int n)
{
	pid_t pid[n];
	int counter=0;
	time_t start_time,end_time;
	while(counter < n)
	{
	 
	    start_time = time(NULL); // to check time.
	    pid[counter] = fork();
	    
		if(pid[counter] == 0)
		{
			permutation(string[counter],0); // execute permutation function at each child processor
			return;
		}
		else if(pid[counter] > 0)
		{
		    
		    wait(); // use wait function so that can check the time child processor used
		    end_time=time(NULL);
		    printf("%ld\n",(end_time-start_time));
		    
		    counter++;
		}

	}
}
int permutation(char* string,int num)
{
	int string_count;
	string_count =strlen(string);
	int i,j;
	char temp;
	if(strlen(string) == num)
	{
	    printf("%s\n",string);
	 
	    return 1;
	}
	
	for(i=num; i < string_count; i++)
	{
	 temp = string[num];
	 string[num] = string[i];
	 string[i] = temp;
	 permutation(string,num+1);
	 string[i] = string[num];
	 string[num] = temp;
	}
}
//same permutation function that used in task1
