#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int permutation(char*,int);
void main()
{
	char string[100];
	// since even 10 characters take a lot of time to execute it, I just allocate static memory.
	printf("Will Test 3 strings\n");
	printf("put string you want to test\n"); // Program will test 3 string for each execution

	printf("1st:");
	gets(string);
	permutation(string,0);
	// after you get string, it will execute permutation function
	printf("2nd:");
	gets(string);
	permutation(string,0);

	printf("3nd:");
	gets(string);
	permutation(string,0);
}

int permutation(char* string,int num)
{
	int string_count;
	string_count =strlen(string);
	int i,j;
	char temp;
	if(strlen(string) == num)
	{
	    printf("%s\n",string);
	 
	    return 1;
	}
	
	for(i=num; i < string_count; i++)
	{
	 temp = string[num];
	 string[num] = string[i];
	 string[i] = temp;
	 permutation(string,num+1);
	 string[i] = string[num];
	 string[num] = temp;
	}
}
// when num is same with the length of string, it will print whole string
//in for loop, It creates recursive function so that whole string can be changed at each alpabet.
