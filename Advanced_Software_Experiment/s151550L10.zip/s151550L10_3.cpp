#include <stdio.h>
#include <random>
#include <time.h>
#include <math.h>
#include <Windows.h>

#define N 25
double Taylor_series(double x, int n);
double Taylor_series_horner(double x, int n);
float Taylor_series_horner_float(float x, int n);
double Taylor_series_improve(double x, int n);

__int64 start, freq, end;
#define CHECK_TIME_START QueryPerformanceFrequency((LARGE_INTEGER*)&freq); QueryPerformanceCounter((LARGE_INTEGER*)&start)
#define CHECK_TIME_END(a) QueryPerformanceCounter((LARGE_INTEGER*)&end); a = (float)((float)(end - start) / (freq / 1000.0f))
float compute_time;

void main(void)
{
	double res;
	float resf;

	CHECK_TIME_START;
	res = Taylor_series(-8.3, N);
	CHECK_TIME_END(compute_time);
	printf("*** normal  f<-8.3> = %.6e , time : %lf\n", res, compute_time);

	CHECK_TIME_START;
	res = Taylor_series_horner(-8.3, N);
	CHECK_TIME_END(compute_time);
	printf("*** horner  f<-8.3> = %.6e , time : %lf\n", res, compute_time);

	CHECK_TIME_START;
	resf = Taylor_series_horner_float(-8.3, N);
	CHECK_TIME_END(compute_time);
	printf("*** float   f<-8.3> = %.6e , time : %lf\n", res, compute_time);

	CHECK_TIME_START;
	res = Taylor_series_improve(-8.3, N);
	CHECK_TIME_END(compute_time);
	printf("*** improve f<-8.3> = %.6e , time : %llf\n", res, compute_time);

	CHECK_TIME_START;
	res = pow(2.71828182846, -8.3);
	CHECK_TIME_END(compute_time);
	printf("*** correct f<-8.3> = %.6e , time : %lf\n", res, compute_time);

}


double Taylor_series(double x, int n)
{
	double answer = 0.0f;
	answer += 1.0f;
	double temp = 1.0f;
	for (int i = 1; i <= n; i++)
	{
		temp = temp * x / i;
		answer += temp;
	}
	return answer;
}

double Taylor_series_horner(double x, int n)
{
	double answer = 0.0f;
	answer = 1.0f;
	for (int i = n; i > 0; i--)
	{
			answer = answer * x / i + 1;
	}
	return answer;

}

float Taylor_series_horner_float(float x, int n)
{
	float answer = 0.0f;
	answer += 1.0f;
	for (int i = n; i > 0; i--)
	{
		answer = answer * x / i + 1;
	}
	return answer;
}

double Taylor_series_improve(double x, int n)
{
	long double answer = 0.0f;
	answer += 1.0f;
	for (int i = n * 4 ; i > 0; i--)
	{
		answer = answer * x / i + 1;
	}
	return answer;
}