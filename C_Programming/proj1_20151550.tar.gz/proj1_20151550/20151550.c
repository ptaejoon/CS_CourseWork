#include<stdio.h>
#include<stdlib.h>

//swap 문은 받은 두 parameter의 값을 바꿔주는 함수이다.
void swap(int *a, int *b)
{
	int temp;
	temp = *b;
	*b = *a;
	*a = temp;
}

//boxchange 함수는 swap문을 이용하며, 작은 상자의 가로 길이와 세로 길이를 바꿔주는 일을 수행하는 함수이다. 
void boxchange(int br, int bh, int **bigbox, int **smallbox, int n)
{
	swap((*(smallbox + n) + 0), (*(smallbox + n) + 1));
}

// 이 코드는 solve 함수 실행 시엔 기본적으노 solve를 실행, solve 라는 재귀함수 내부에서 twosquare라는 재귀 함수를 실행시킨다. 이 두 함수를 통해 작은 상자들이 큰 상자(방) 에 들어갈 때 회전을 했는지 안했는지, 어떤 번호를 가진 상자가 먼저 들어가는지를 확인한다. twosquare 내부에서는 functioncycle_allarray라는 함수가, 이 함수는 functioncycle 이라는 함수를, 마지막으로 이 함수는 function 이라는 함수를 불러낸다. 이 과정에서 이전 함수에서 정해진 순서와 회전의 경우를 직접 큰 상자 (방)에 넣어보면서 가장 많은 개수를 세고, 그 때의 큰 상자(ㅑ방)의 모습을 저장해둔다. 

// 방의 가장 왼쪽 가장 위쪽을 (0,0) 이라고 하고, 오른쪽으로 가는 방향을 +x, 아래로 내려 가는 방향을 +y 축이라 할 때, 주어진 점 (br,bh) 에서 n번째 상자가 들어갈수 있는지 확인 한 뒤, 들어갈 수 있다면 그대로 bigbox(방)의 그 위치에 넣어준다.
int function(int br,int bh,int n,int **bigbox,int **smallbox,int realbr,int realbh, int *a)
{
	int count2,count3;
	int count4,count5;
	int sh,sr;
	sh = *(*(smallbox+n));
	sr = *(*(smallbox+n)+1);
	// 큰 상자 내부의 임의의 점 (br,bh)에 세로 , 가로의 길이가 각각 sh, sr인 작은 상자를 넣을 수 있는지 검사하고, 가능하다면 넣는 과정이다.
	if (bh + sh > realbh || br + sr > realbr) 
	{
		return 0;
	}
	// realbh,realbr은 실제 큰 상자(방)의 세로 , 가로의 길이이다. 이 길이의 값보다 임의의 점에서 sh길이 만큼 이동한 값이 크다면 메모리 할당을 하지 않은 곳을 건드리면서 오류가 발생하기 때문에 오류가 나지 않게 해준다.
	for(count2 = 0; count2 < sh; count2++) 
	{
		for(count3 = 0; count3 < sr; count3++)
		{
			
			if (*(*(bigbox + bh + count2) + br + count3) != 0)
			{
				return 0;
			}
			// 임의의 점 (br,bh) 에서부터 작은 상자를 채워 넣을 때, 다른 값이 이미 그 공간에 존재한다면 넣지 않고0을 반환한다.
			if(*(*(bigbox + bh + count2)+ br +count3) == 0 && count2 == sh-1 && count3 == sr-1)
			{	
			// 작은 상자가 들어갈 공간 전부 0임을 검사하면, 작은 상자를 채워넣는다.
				for(count4 = 0; count4 <sh; count4++)
				{
					for(count5 = 0; count5 < sr; count5++)
					{
						*(*(bigbox + bh + count4)+br+count5) = *(a+n)+1;	
						// *(a+n) + 1 값을 넣어준다. 그냥 n 값을 넣어주는 경우, 상자가 들어가는 순서가 바뀔 때, n번 상자의 값이 n이 아니라 다른 수가 들어가는 경우가 생긴다. 그렇기 때문에 상자가 들어가는 순서가 바뀔 때, 상자의 번호도 같이 이동해야 한다. 그렇기 위해서, n 대신 a라는 배열을 이용해서 값을 넣어주는 것이다.  
					}
				}
				return 1;
				// 상자가 들어갔음을 알린다.
			}
			
		}
	}	
}

// function 함수를 반복적으로 돌려주는 함수이다. 이 함수는 각각의 작은 상자를 임의의 점 (br,bh)로 시작하는 경우를 대입해준다.즉, 1번 상자부터, 마지막 번 상자까지 (br,bh) 점으로 시작하는 구역에 넣어보는 함수인 것이다.  만약 (br,bh)에서 상자가 들어가면 1 값을 반환받고, 가장 안쪽의 if문을 수행한다. 이 if문을 통해서, n번째 상자가 이미 큰 상자(방)안에 배치되었음을 표시할 수 있고, (br,bh)엔 상자가 들어갔음을 통보할 수 있다.
int functioncycle(int br, int bh, int n, int **bigbox, int **smallbox,int realbr,int realbh, int *check, int *a)
{
	int count;
	for( count=0; count < n; count++)
	{
		if(*(check + count) != 1)
		{
			if (function(br, bh, count, bigbox, smallbox, realbr, realbh,a))
			{
				*(check + count) = 1;
				// check 배열은 count+1번째도형이 큰 상자(방) 안에 배치되어 있나 검사하는 함수이다.
				// if(*(check + count) != 1) 문을 이용해서 *(check +count) 값이 1이면 이미 count+1번째 상자는 들어잇다는 뜻이므로 이 작은  상자는 함수를 돌면서 다시 한 번 사용하지 않는다.
				return 1;
			}
		}
	}
	return 0;
}

//functioncycle을 큰 상자의 모든 구역에서 돌려주는 함수이다. functioncycle 함수가 function 함수를 모든 작은 상자의 경우에 돌리는 함수였다면, 이 함수는 큰 상자(방)의 모든 좌표에서 functioncycle을 실행시켜보는 함수이다. 또한 이를 통해 result라는 변수에 작은 상자가 몇개가 들어갔는가를 반환하는 함수이다.
int functioncycle_allarray(int br, int bh,int **bigbox, int **smallbox, int n, int *a )
{
	int *check;
	check = (int*)calloc(n+1,sizeof(int));
	int count,count2;
	int result= 0;
	for (count = 0; count < bh; count++)
	{
		for (count2 = 0; count2 < br; count2++)
		{
			*(*(bigbox + count) + count2) = 0;
		}
	}
	// bigbox 배열은 작은 상자들을 넣어서 값을 계산하기 때문에, 다음 계산에 이용하기 위해서는 그 전에 항상 초기화를 해두어야 한다. 따라서 초기화를 위해서 이 반복문을 사용하였다. 이를 통해 매번 함수를 돌릴 때마다 bigbox의 모든 값은 초기화 될 수 있는 것이다.
	
	for(count = 0; count < bh; count++)
	{
		for(count2 = 0; count2 < br; count2++)
		{
			result += functioncycle(count2,count,n,bigbox,smallbox,br,bh,check,a);
			// 큰 상자(방)의 모든 구역에서 그 구역에 작은 상자가 들어가는가 검사할 때마다 return하는 값인 1을 result 값에 더해줌으로서 result값이 큰 상자(방)에 작은 상자가 몇 개 들어가는지를 나타내게 만들 수 있다.	
		}	
	}
	free(check);
	return result;
}

// 함수 twosquare은 각각의 상자가 가로 세로가 바뀌는 경우를 가정해서 순서를 만드는 함수이다. 상자가 들어가는 순서는twosquare 함수를 불러주는 solve함수에서 정하고, twosquare에선 solve가 만든 순서대로 있는상자들을 각각 회전시켜보는 것이다. 그 경우의 수는 2의 n승이 된다. 
int twosquare(int n,int br, int bh, int **bigbox, int **smallbox, int *result,int count_n,int **bigbox_copy,int *a)
{ 
	int count;
	int count2,count3;
	int value;
	count_n += 1; // 재귀함수를 작동시키기 위한 변수
	if(*result == n)
	{
		return 2; // 모든 경우의 수를 다하는 전수조사는 실행 속도가 느린 편이다. 이때 확실한 경우인 모든 상자가 다 들어간 경우엔 더이상의 박스 패킹을 그만하고 바로 결과를 출력하게 만든다.
	}
	if(count_n < n)
	{ // n번을 돌린다. solve에서 -1로count_n을 받았기에 n번돌릴 수 있다.
		for(count = 0; count <= 1; count++)
		{ // 2번만 돌리면 된다. count_n번째 의 상자를 회전시킬 때와 안시킬 때를 구분짓는다.
			
			value = functioncycle_allarray(br,bh,bigbox,smallbox,n,a); // 상자가 몇개가큰 상자(방)에 들어갔는가 확인한다. 
			if(value > *result)
			{
				*result = value;
				// 그러다가 새로 받은value가 원래 result값보다 크면 새로 값을 넣어주고, 그 때의 큰 상자(방)의 내부를 bigbox_copy에다가 저장해둔다.
				for(count2 = 0; count2 < bh; count2++)
				{
					for(count3 = 0; count3 < br; count3++)
					{
						*(*(bigbox_copy+count2)+count3) = *(*(bigbox+count2)+count3);
						
					}
					

				}
			}
			twosquare(n, br, bh, bigbox, smallbox, result, count_n, bigbox_copy,a);
			// 재귀함수를 작동시킨다. 이를 통해 첫 번째 상자부터 n번 째 상자까지 회전을시킬 떄, 안시킬 때를 전부 다룰 수 있다.
			boxchange(br, bh, bigbox, smallbox, count_n);
			// boxchange 함수는 작은 상자의 가로, 세로 값을 바꿔준다.
		}
		
	}
	
}

//solve 함수는 전체적으로 모든 함수들을 작동시키는 함수이다. 이 함수에서는 작은 상자들의 들어가는 순서를 모든 경우에 대해 만들어준다. 즉 n!개의 들어가는 상자 순서의 경우의 수를 만들어주는 함수이다. 
int solve(int n, int br, int bh, int **bigbox, int **smallbox, int *result, int **bigbox_copy, int i,int *a)
{

	int find=0;
	int count = i;
	if (i == n)
	{
		find =twosquare(n, br, bh, bigbox, smallbox, result, -1, bigbox_copy,a); // n개의 상자의 순서를 다 정한 다음에는 twosquare를 실행시켜 회전을 고려한 뒤 , 채워넣기를 시작한다.
	}
	else
	{
		
		for ( count; count < n; count++)
		{
			
			swap((*(smallbox +i)), (*(smallbox + count)));
			swap((*(smallbox + i) + 1), (*(smallbox + count) + 1));
			swap((a + i), (a + count));

			solve(n, br, bh, bigbox, smallbox, result, bigbox_copy, i + 1, a);
		
			swap((*(smallbox + i)), (*(smallbox + count)));
			swap((*(smallbox + i) + 1), (*(smallbox + count) + 1)); 
			swap((a + i), (a + count));
			if(*result == n)
			{
				return 2;
				// n개가 전부 들어간다면 이미 상자 수를 파악한것이기 때문에 바로 출력하도록 만든다.
			}
			
		}	
		
	}
	// 이 재귀함수를 통해 모든 상자의 배치 순서를 만들어낸다.
}

 //------- addition_twosquare 와 addition_solve 는 추가 구현에 사용되는 함수이다.

 //------- addition_twosquare는 twosquare와 기능이 유사하지만, 추가 구현을 위해 만든 함수이다. functioncycle_allarray를 실행해 어떤 순서의 작은 상자들을 넣었을 때, 처음부터 끝까지 큰 상자(방)의 값에 0이 없다면, 그 값이 추가 구현을 만족하는 상자배치이므로 이를 bigbox_copy에 옮겨 저장한다.
int addition_twosquare(int n, int br, int bh, int **bigbox, int **smallbox, int *addition_result, int count_n, int **bigbox_copy, int *a)
{
	
	int count;
	int count2, count3;
	int count4, count5;
	int value;
	int num;
	count_n += 1;
	if(*addition_result == 1)
	{
		return 1;
		// 꽉 찬것을 확인하면 바로 더 이상의 함수 반복을 종료한다.
		// 즉 Yes 인 케이스는 No 인 케이스보다 더 일찍 끝낼 수 있을 것이다.
	}
	if (count_n < n)
	{
		for (count = 0; count <= 1; count++)
		{
			num = 2;
			functioncycle_allarray(br, bh, bigbox, smallbox, n, a); // 큰 상자(방) 안에 상자들을 넣는다.
			for (count4 = 0; count4 < bh; count4++)
			{
				for (count5 = 0; count5 < br; count5++)
				{
					if (*(*(bigbox + count4) + count5) == 0)
					{
						num = 0;
						break;
						// 만약 큰 상자(방)에 0 이 있다면 더 검사할 필요가 없다. break 하고,count4에 대한 for문도 break 해준다.
					}
					else
					{
						if (count4 == bh - 1 && count5 == br - 1)
						{ // 배열을 다 돌릴 때까지 모든 구역에 0이 없었던 경우이다.
							num = 1;
							*addition_result = 1; // addition_result가 1일 때 YES를 반환한다.
					
							for (count2 = 0; count2 < bh; count2++)
							{
								for (count3 = 0; count3 < br; count3++)
								{
									*(*(bigbox_copy + count2) + count3) = *(*(bigbox + count2) + count3);

								}
							}
							
						}
						
					}
					
				}
				
				if (num == 0)
				{
					break;
				}
			}

			addition_twosquare(n, br, bh, bigbox, smallbox, addition_result, count_n, bigbox_copy, a);

			boxchange(br, bh, bigbox, smallbox, count_n);

		}	// 이 식은 twosquare과 유사하지만, 추가 구현을 실행하도록 바뀌었다.

	}

}
// ------ addition_solve 함수는 추가 구현을 실행시키기 위한 함수이다. 원래의 solve함수와 같이, 상자가 들어갈 순서를 정렬한 뒤 , addition_twosquare을 불러내서 계산을 실행한다.
int addition_solve(int n, int br, int bh, int **bigbox, int **smallbox, int *addition_result, int **bigbox_copy, int i, int *a)
{
	
		int check = 0;
		int find = 0;
		int count = i;
		if(*addition_result == 1)
		{
			return 1;
		} // 꽉 찬 것을 확인하면 더 이상 함수를 돌리지 않고 결과를 도출시켜준다.
		if (i == n)
		{
			find = addition_twosquare(n, br, bh, bigbox, smallbox, addition_result, -1, bigbox_copy, a);
		
		}
		else
		{

			for (count; count < n; count++)
			{

				swap((*(smallbox + i)), (*(smallbox + count)));
				swap((*(smallbox + i) + 1), (*(smallbox + count) + 1));
				swap((a + i), (a + count));

				check = addition_solve(n, br, bh, bigbox, smallbox, addition_result, bigbox_copy, i + 1, a);

				swap((*(smallbox + i)), (*(smallbox + count)));
				swap((*(smallbox + i) + 1), (*(smallbox + count) + 1));
				swap((a + i), (a + count));
	
			}

		}
}
int main()
{
	int br,bh;
	int n; 
	int count,count2;
	int** bigbox; // 큰 상자의 크기만큼 할당받는다.
	int** smallbox; // 작은 상자들의 세로, 가로의 길이를 입력받는다.
	int** bigbox_copy; // solve 및 추가 구현 함수에서 값을 도출해 냈을 때순간의 큰 상자의 배치 형태를 저장하는 배열.
	int result=0; // solve 함수에서 들어가는 작은 상자의 최대개수를 받는 변수.
	int *a; // 이 함수는 작은 상자를 큰 상자에 옮길 때순서가 바뀌면  상자의 번호가 바뀌는 것을 방지하기 위해 구현한 배열이다.
	int addition_result = 0; // 추가 구현 함수에서 YES 인지 NO 인지 판별값을 받는 변수.
	scanf("%d %d %d", &bh, &br, &n); // bh 는집어넣어야 하는 큰 상자의 세로, br은 집어넣어야 하는 큰 상자의 가로이며, n은 입력받는 작은 상자의 개수이다.
	// ------ 큰 상자의 크기만큼 이차원 배열을 생성 --- 
	bigbox = (int **)malloc(sizeof(int *) * bh); 
	bigbox_copy = (int **)malloc(sizeof(int *) * bh); 
	for(count = 0; count < bh; count++)
	{
		*(bigbox+count) =(int *)calloc(br,sizeof(int));
		*(bigbox_copy+count) = (int *)calloc(br,sizeof(int));
	}

	// ------작은 상자의 이차원 배열을 생성 ---

	smallbox = (int **)malloc(sizeof(int *) * n);
	a = (int *)malloc(sizeof(int) * n);
	for(count = 0; count < n; count++)
	{
		*(smallbox + count) = (int *)malloc(sizeof(int) * 2); // 세로, 가로의 길이를 받기 때문에 2개씩 할당해주면 된다.
		*(a + count) = count;
	}

	// ------작은 상자들의 가로, 세로의 길이를 받기 ---
	for(count = 0; count < n; count++)
	{
		scanf("%d %d",*(smallbox+count),*(smallbox+count)+1);
	}
	
	// ----- solve 함수를 구현 ---
	solve(n,br,bh,bigbox,smallbox,&result,bigbox_copy,0,a);

	// ----- solve 함수를 돌은 뒤, 최대로 들어간 갯수가얼마인지를 출력
	printf("%d\n",result);
	
	// ----- bigbox_copy는 상자가 최대로 들어갔을 때의 bigbox 의 상태를 저장해뒀으므로 이를 그대로 출력하면 result의 최대값에서의 배열상태가 나온다.
	
	for (count = 0; count< bh; count++)
	{
		for (count2 = 0; count2<br; count2++)
		{
			printf("%d", *(*(bigbox_copy + count) + count2));
		}
		printf("\n");
	}
	
	// ------ solve함수를 완료했으면, addition_solve, 즉 추가 구현을 실행한다.
	addition_solve(n, br, bh, bigbox, smallbox, &addition_result, bigbox_copy, 0, a);

	// ------ 추가 구현을 통해 얻은 addition_result 가 0이면 이는 꽉 채우지 못했음을 나타내고, addition_result가 1이면 꽉 채웠다는 것이기 때문에 YES값을 출력 후, 꽉 찬 상태의 큰 상자 모습을 출력한다.
	if (addition_result == 0)
	{
		printf("NO\n");
	}
	else
	{
		printf("YES\n");
		for (count = 0; count< bh; count++)
		{
			for (count2 = 0; count2<br; count2++)
			{
				printf("%d", *(*(bigbox_copy + count) + count2));
			}
			printf("\n");
		}
	}

	// ------ 함수를 다 돌았으므로, 동적 할당했던 배열들을 전부 free로 메모리 할당 해제를 해준다.
	for(count = 0; count < bh; count++)
	{
		free(*(bigbox+count));
		free(*(bigbox_copy+count));
	}
	free(bigbox);
	free(bigbox_copy);
	for(count = 0; count < n; count++)
	{
		free(*(smallbox+count));
	}
	free(smallbox);
}
