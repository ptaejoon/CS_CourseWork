#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct rent* rptr;
typedef struct rent
{
	char date[11];
	int mnum;
	int vnum;
	struct rent* link;
}Rent;
/* 구조체 Rent는 현재 대여된 상태에 있는 비디오의 정보를 저장하기 위해 만든 구조체이다.
date는 char형으로 대여 날짜인 yyyy-mm-dd를저장하는 변수이다.
mnum은 빌려가는 회원의 정보가 들어있는 배열의 번호를 저장하는 변수이다.
vnum은 대여되는 비디오의 정보가 들어있는 배열의 번호를 저장하는 변수이다.
이 두 변수로 어느 비디오가 어느 회원에게 대여되었는지 알 수 있다. 그 방법은 추후 함수를 설명하며 이야기하도록 한다.
link는 Rent라는 구조체를 linked list로 사용하기 위해 이용된다. */

typedef struct member* mptr;
typedef struct member{
	char id[11];
	char name[91];
	char phone[30];
}Member;
/* 구조체 Member은 가입된 회원들의 정보를 저장하기 위해 만든 구조체이다.
id는 영문과 숫자로만 이루어지는 id를 받기 위해 번호를 저장하는 변수이다.
name은 가입자의 이름을 저장하는 변수이다.
phone은 전화번호를 저장한다. */

typedef struct video* vptr;
typedef struct video{
	char ISBN[30];
	char title[91];
	int genre;
}Video;
/* 구조체 Video는 등록된 비디오들의 정보를 저장하기 위해 만든 구조체이다.
ISBN은 숫자와 - 로 구성된 ISBN을 저장하는 변수이다.
title은 한글과 영어로 구성된 제목을 저장하는 변수이다.
genre는 그 비디오의 장르 번호를 저장하는 변수이다. */

typedef struct videolog* vlptr;
typedef struct videolog
{
	int mnum;
	int vnum;
	char date[11];
	struct videolog* link;
}Videolog;
/* 구조체 Videolog는 그동안의 대여기록을 모두 저장하기 위해 만든 구조체이다.
Rent와 다르게 Videolog는 모든 대여기록을 삭제하지 않는다. 이는 함수를 설명하며 추가로 설명하도록 한다.
mnum,date,vnum 모두 렌트에서처럼 배열의 번호들과 대여날짜를 기록하는 변수이다.
link또한 Rent처럼 Videolog도 linked list로 사용하기 위해 사용되었다. */


int CheckISBN(char* n)
{
	int len = strlen(n);
	int num;
	int dashcount=0;
	// ISBN의 올바른 꼴 (숫자 - 숫자 - 숫자)
	if(n[0] == '-' || n[len-1] == '-')
	{
		return 0; // 맨 처음과 끝에 - 가 존재하면 오류.
	}
	for(num = 0; num < len; num++)
	{
		if(n[num] == '-')
		{
			dashcount++;
			if(n[num] == n[num+1] && num < len-1)
			{
				return 0; // -가 바로 연속으로 존재하면 오류.
			}
		}
		else if(n[num] >= '0' && n[num] <= '9')
		{
			continue; // 숫자인 경우.
		}
		else
		{
			return 0;
			//ISBN이 숫자나 -가 아닌경우 형식이 틀림.
		}
	}
	if(dashcount == 2)
	{
		return 1; // for문을 다 돌았을때 -가 2개여야함.
	}
	else
	{
		return 0; // 그렇지 않으면 오류.
	}
}
/*CheckISBN은 ISBN을 체크하는 함수이다. ISBN의 형태가 올바른지 검사하는 함수이다. 형태가 올바를때 1을, 틀릴 때 0을 반환한다.
*n = 외부에서 검사할 ISBN을 받아온다.
len = ISBN의 길이 숫자와 -를 포함한 수이다. ( ex] 000-00-0 => 8)
num = for문을 돌리기 위해 사용되는 변수.
dashcount = -의 개수를 센다. -가 2개만 존재해야 ISBN의 양식이 맞기 때문이다. */

int CheckPhone(char* n)
{
	int len=strlen(n);
	int num;
	int dashcount=0;
	if(n[0] == '-' || n[len-1] == '-')
	{
		return 0; // 맨 앞자리나 맨 뒷자리에 -가 들어오면 올바른 휴대전화 번호의 형태가 아니다.
	}
	for(num = 0; num < len; num++)
	{
		if(n[num] == '-')
		{
			dashcount++; // -일때마다 1씩 더함.
			if(n[num] == n[num+1] && num < len-1)
			{
				return 0; // -가 연속으로 존재하는지 확인.
			}
		}
		else if(n[num] >= '0' && n[num] <= '9')
		{
			continue; //숫자인 경우 그냥 넘어감
		}
		else
		{
			return 0; // 숫자와 - 외에 다른 문자가 들어오면 오류로 받아들임
		}
	}
	if(dashcount == 2)
	{
		return 1; // for문을 나오고 -가 2개이면 올바른 전화번호 형태임을 알았기에 1을 반환
	}
	else
	{
		return 0;// 그렇지 않으면 0을 반환.
	}

}
/*CheckPhone 함수는 전화번호의 형태가 올바른지 검사하는 함수이다. 전화번호의 꼴이 올바를 때 1을, 그렇지 않으면 0을 반환한다. (숫자 - 숫자 - 숫자)를 올바른 형태로 취급한다.
위의 CheckISBN과 형태가 매우 유사하다.
*n : 외부에서 가져오는 검사해야할 입력된 폰번호이다.
len : 받아온 폰번호의 길이. 숫자와 -를 포함한다.
num : for문을 사용하기 위해 사용하는 변수
dashcount : -의 개수를 세는 변수. 올바른 전화번호 형태는 -가 2개이다.*/
void NewMember(mptr *n,int *count)
{
	getc(stdin); // main문에서 숫자대신 %c를 받으면서 엔터까지 받기 때문에, 오류가 발생하지 않기 위해 함수에 들어오면서 엔터를 한번 받아준다.
	char phone[30];
	int num;
	int strlong=0;
	int realstrlong=0;
	char id[30];
	char name[150];
	// ID 검사
	printf("ID를 입력해주세요.\nID : ");
	gets(id); 
	if(strlen(id)>10)
	{
		printf("아이디를 입력할 수 있는 데이터 용량을 초과하셨습니다.\n");
		return; // 아이디가 10글자보다 크면 실패 문구를 출력하고 배열에 값을 저장하지 않는다.
	}
	for(num = 0; num < 10; num++)
	{
		// 아이디가 숫자, 영문으로만 이루어져있는지 확인.
		// 맞다면 다음으로 넘어가고, 그렇지 않으면 return해서 함수를 종료.
		if(id[num] == '\0')
		{
			break;
		}

		if(id[num] >= '0' && id[num]<= '9')
		{
		}
		else if(id[num] >= 'a' && id[num]<='z')
		{
		}
		else if(id[num] >= 'A' && id[num]<='Z')
		{
		}
		else
		{
			printf("ID에는 영문과 숫자만 사용가능합니다.\n");
			return;
		}
	}
	for(num = 0; num < *count; num++)
	{
		//존재하는 Clist의 명단들과 비교해서 이미 존재하는 아이디인지, 아닌지 확인. 이미 존재한다면 함수를 종료.
		if(strcmp(id,(*n)[num].id) == 0)
		{
			
			printf("이미 존재하는 아이디입니다. 다른 아이디를 사용해주세요.\n");
			return;
		}
	} 
	// 모든 조건에 부합하면, 이름을 받기 시작.
	printf("이름을 입력해주세요. \n이름 : ");
	gets(name); 
	strlong=strlen(name); // 이름의 길이. strlong은 한글의 유무를 고려 못하는 글자크기임. 글자 수를 판별할 새로운 변수가 필요함.
	realstrlong = strlong; // realstrlong은 strlong의 값에서 한글임을 알게 될 때 그 값에서 -2를 해줌으로서 strlen에서 3을 차지하는 한글을 1로 취급하게 만들어 string의 byte수가 아닌 글자수를갖는 변수가 되는 것이다. 
	if(strlong > 90)
	{
		printf("입력할 수 있는 데이터 용량을 초과하셨습니다.\n");
		return; // 한글로마저 총 30글자가 넘으면 받지 않는다.
	}
	for(num =0; num<strlong;num++)
	{
		//이름이 한글 혹은 영문이 아닌지 맞는지 확인.
		//맞으면 그대로 넘어가고, 아니면 틀렸다고 출력한 뒤 함수를 종료.
		if(name[num] == '\0')
		{
			break;
		}
		if(name[num] >= 'a' && name[num] <= 'z')
		{
		}
		else if(name[num] >= 'A' && name[num] <='Z')
		{
		}
		else if(name[num] <= -19 && name[num] >= -22)
		{
			//한글의 가 부터 힣까지 글자들이 갖는 첫 바이트의 char 값이 -19와 -22 사이에 있었다. 
			//한글의 첫 바이트임을 확인했으면 나음 두개의 바이트 값은 검사하지 않고 넘어가며, realstrlong의 값을 2를 뺴줘서 한글 바이트수 3 중에 2를 빼준다.
			num+=2;
			realstrlong -= 2; 
		}
		else if(name[num] == -29)
		{
			//모음, 자음으로만 되어있는 글자들이 갖는 첫 바이트의 char값이 -29였다.
			num+=2;
			realstrlong -= 2;
		}
		else
		{
			printf("이름엔 한글, 영문만 사용가능합니다. \n");
			return;
		}
	}
	// 여기까지 돌면 realstrlong의 값이 원래는 글자의 바이트 수를 가리키다가 글자 수를 가리키게 된다. 따라 여기서 30글자를 넘는지 확인한다.
	if(realstrlong > 30)
	{
		printf("최대 허용 글자 수인 30글자를 넘어섰습니다.\n");
		return;
	}
	//이 과정까지 함수가 돈다면 id 입력과 이름 입력을 완수한 것이다.
	//전화번호 검사 시작.
	printf("전화번호를 입력해주세요. \n번호 : ");
	gets(phone); 
	if(CheckPhone(phone)) // 전화번호의 형식을 검사하는 함수가 1을 반환하면 그냥 넘어가게 된다. 1을 반환할 때에는 전화번호의 형식이 올바름을 의미한다. 0을 반환하면 전화번호의 형식이 잘못되었음을 의미한다.
	{
	}	
	else
	{
		printf("전화번호 형식이 잘못되었습니다.\n");
		return;
	}
	//모든 조건을 다 확인했을 때, 다 부합한다면 Clist에 동적 할당을 해서 값을 저장한다.
	//Clist가 NULL일 경우엔 새로 할당을, 원래 값이 존재할때는 realloc을 해주어서 새 배열공간을 하나 추가해낸다.
	if(*count == 0)
	{
		*n = (mptr)malloc(sizeof(Member));
		*count += 1;
	}
	else
	{
		*n=(mptr)realloc(*n,(*count+1)*sizeof(Member));
		*count += 1;
	}
	//새로 만든 메모리 공간에 원래 검사했던 값들을 복사해감.
	strcpy((*n)[*count-1].id,id);
	strcpy((*n)[*count-1].name,name);
	strcpy((*n)[*count-1].phone,phone);
	printf("가입이 완료되었습니다.\n");
}
/*NewMember 함수는 새로운 고객을 가입시킬 때 사용하는 함수이다. Clist라는 구조체의 배열들을 받아서 고객의 정보를 저장한다. 배열로 저장하는 이유는, 구조체 Rent에서사용하는 mnum값을 얻기위해서이다. 즉, Clist[k]는 mnum이k라는 고객이 되는것이다. 
배열에 직접 저장을 하기 전에, 임의의 다른 변수들에 값을 저장하고 이를 검사한 뒤, 조건에 부합하면 Clist의 배열을 새로 할당해서 그 곳에 값을 저장하고, 조건에 부합하지 못하면 옳지 못한 입력이라고 하고 실행을 종료한다.
*n : Clist를 받음. 고객의 정보를 저장하는 변수의 파라미터이다.
*count : Clist_count를 받음.
phone : 전화번호를 임시로 저장하는 변수. 조건에 합당할 시 이 값을 배열로 옮긴다.
num : for문을 사용하기 위해 사용하는 변수
strlong : 이름을 검사할 때 사용하는 변수. 먼저 이 변수에 입력받은 이름의 크기를 저장한다. (strlen의 값) 한글은 영어와 달리 3바이트를 차지하기 때문에 한 글자당 strlen값이 3을 차지한다. strlong에서는 영어와 한글이 구분이 안돼있기 때문에 이를 검사하는 과정을 요구한다.
realstrlong : strlong에서 한글을 구별해서 실제의 글자수를 저장하는 변수. 
id : id를 임시로 저장하는변수. 조건에 합당할 시 이 값을 배열에 옮겨준다.
name : 이름을 임시로 저장하는 변수. 조건에 합당할 시 이 값을 배열로 옮긴다. */

void MemberSearch(mptr n,int *count)
{
	getc(stdin); // 이전함수와 마찬가지로 메인문에서 들어오는 엔터를 임의로 받아낸다.
	int num;
	char find[30];
	// 애초에 Clist의 값이 하나도 없을 때는 등록된 회원이 없다고 말한다.
	if(n==NULL)
	{
		printf("현재 등록된 회원이 없습니다.\n");
		return;
	}
	printf("찾는 ID 입력 : ");
	gets(find);
	// id의 길이는 애초에10글자 이내이다. 따라서 이보다 크면 오류임을 출력한다.
	if(strlen(find) > 10)
	{
		printf("아이디는 영어 및 숫자로만 되어있으며, 10 자를 넘지 않습니다.\n");
		return;
	}
	// 입력받은 id를 find에 저장해놨기 때문에, 기존에 Clist에 존재하던 고객들의 id와 이를 strcmp를 이용해 비교하고, 일치하는 사람이 있으면 그 사람의 정보를 출력한다.
	for(num = 0; num <*count; num++)
	{
		if(strcmp(find,n[num].id) == 0)
		{
			printf("------------------------------\n");
			printf("-> ID : %s\n",n[num].id);
			printf("-> 이름 : %s\n",n[num].name);
			printf("-> 전화번호 : %s\n",n[num].phone);
			printf("------------------------------\n");
			return;
		}
		else
		{
			if(num == *count-1)
			{
				printf("찾으시는 ID가 존재하지 않습니다.\n");
				//모든 리스트를 다 검사했을때도 정보가 존재하지 않는다면, 찾는 ID가 없음을 의미한다.
			}
		}
	}
}
/*MemberSearch 함수는 등록되어있는 고객들의 정보를 조회하는 함수이다. 메인 함수의 Clist를 가져와 검색에 활용한다. 찾는 ID를 입력받아 이 ID가 존재하는지 확인하고, 있다면 그 정보를 반환하는 함수이다.
n : Clist를 받는 파라미터이다. 고객들의 정보를 가지고 있는구조체들의 배열이다.
count : Clist의 배열의 개수를 나타내는 변수인 Clist_count를 받는 파라미터이다.
num : for문을 돌리기 위해 사용하는 변수
find : 조회하기 위해 입력받은 id를 저장해두는 함수이다. */

void RegisterVideo(vptr *n,int *count)
{
	getc(stdin); // 이전 함수들과 마찬가지로 main함수에서 입력받는 엔터를 받기 위해 사용.
	int num;
	char ISBN[30];
	char title[200];
	int titleleng;
	int realtitleleng;
	int genre;
	printf("ISBN을 입력해주세요.\n입력 : ");
	gets(ISBN);

	if(CheckISBN(ISBN) == 1)
	{
	//ISBN이 올바른 형태를 가지고 있는지 검사하는 함수인 CheckISBN에 입력받은 ISBN을 돌려 검사해본다.
	//1을 반환받을 때는 올바른 형태를 가지고 있다는 것이고, 그 다음으로 넘어가게 된다.
	//0을 반환받을 때는 ISBN의 형태가 잘못되었다는 것이고, 이는 입력형식이 잘못되었다고 통보하고 함수를 종료한다.
	}
	else
	{
		printf("입력형식이 잘못되었습니다!\n");
		return;
	}
	for(num = 0; num <*count; num++)
	{
	// 이전에 있던 비디오의 ISBN들을 검사해서 중복되는 ISBN이 있나 확인한다.
		if(strcmp(ISBN,(*n)[num].ISBN)==0)
		{
			printf("이미 등록되어있는 ISBN 입니다.\n");
			return;

		}
	}
	//여기까지 함수가 작동된다면 올바른 ISBN이 입력되었다는 것이다.
	printf("제목 입력 : ");
	gets(title);
	titleleng=strlen(title);
	realtitleleng=titleleng;
	if(titleleng>90)
	{
	//한글이 3바이트이므로 한글로 최대 30글자를 받았을때도 strlen이 90을 넘지 않기 떄문에 이를 넘으면 글자수를 초과했음을 알린다.
		printf("입력이 잘못되었습니다!\n입력받을 수 있는 제목의 크기를 넘었습니다!\n");
		return;
	}
	for(num = 0; num < titleleng; num++)
	{
	//제목이 한글 혹은 영어로만 쓰여있는지 아닌지 확인한다.
	//한글일 때는 realtitleleng을 2씩 줄여서 글자의 바이트수가 아닌 글자 개수를 저장하도록 만든다.
	//한글 혹은 영어 둘 다 아닐 경우는 잘못 입력되었음을 출력하고 함수를 종료한다.
		if(title[num] == '\0')
		{
			break;
		}
		if(title[num] >= 'a' && title[num] <='z')
		{
		}
		else if(title[num] >= 'A' && title[num] <= 'Z')
		{
		}
		else if(title[num] >= -22 && title[num] <= -19)
		{
			realtitleleng -=2;
			num += 2;
		}
		else if(title[num] == -29)
		{
			realtitleleng -=2;
			num += 2;
		}
		else
		{
			printf("제목 형식이 잘못되었습니다!\n제목 형식은 영문과 한글만 사용가능합니다.\n");
			return;
		}
	}
	//realtitleelng이 글자수를 의미하므로 글자수가 30개가 넘는지 확인한다.
	if(realtitleleng > 30)
	{
		printf("입력할 수 있는 제목의 크기를 초과하였습니다!\n 제목은 30자까지만 입력받을 수 있습니다.\n");
		return;
	}
	// 여기까지 왔으면 타이틀을 완전히 입력받은 것이다.
	// 여기서부터는 장르를 입력받는다.
	printf("장르 입력 <1. 액션.2. 코믹.3. SF.4. 로맨틱> : ");
	scanf("%d",&genre);
	getc(stdin);
	// 1~4까지의 경우 옳은 값이므로 넘어간다. 그 외에는 잘못 입력했음을 입력하고 함수를 종료해버린다.
	if(genre >= 1 && genre <= 4)
	{
	}
	else
	{
		printf("장르 입력을 잘못하셨습니다.\n");
		return;
	}
	// 모든 경우가 조건을 만족할 때 이를 Vlist에 새로 저장해준다. 이를 위해서 새로 메모리 할당을 해준다.
	if(*count == 0) // 애초에 Vlist가 비어있을때는 malloc으로 새 메모리공간을 만들어준다.
 	{
 		*n = (vptr)malloc(sizeof(Video));
		*count += 1;
 	}
 	else // Vlist가 원래 존재할때는 realloc으로 기존 메모리 공간에 새 메모리공간을 추가로 늘려준다.
 	{
 		*n = (vptr)realloc(*n,sizeof(Video)*(*count+1));
		*count += 1;
 	}
	strcpy((*n)[*count-1].ISBN,ISBN);
	strcpy((*n)[*count-1].title,title);
	(*n)[*count-1].genre = genre; // 임시로 저장되있던 값들을 Vlist의 배열 내로 옮겨 저장한다.
	printf("등록이 완료되었습니다.\n");
}
/* RegisterVideo는 비디오를 등록하는 함수이다. 메인함수의 Vlist 비디오정보를 저장하는 구조체 배열을 가져와 조건에 부합할 때 이 배열에 메모리를 새로 할당하고 데이터를 저장하는 함수이다.
n : 메인 함수에 있는 비디오정보를 저장하는 배열인 Vlist의 파라미터이다. 만약 입력된 정보가 조건에 부합한다면 이 배열에 그 데이터를 저장한다.
count : 메인 함수에 있는 비디오정보의 개수를 나타내는 Vlist_count의 파라미터이다.
num : for문을 사용하기 위해 사용하는 변수
ISBN : 입력된 ISBN을 임시로 저장하고 조건에 부합하는지 검사하기 위해 사용하는 변수.
title: 입력된 제목을 임시로 저장하고 조건에 부합하는지 검사하기 위해 사용하는 변수.
genre : 입력된 장르의 번호를 저장받는다. 그 번호가 1~4 사이인지 검사하기 위해 사용한다.
titleleng : 제목을 검사할 때 사용하는 변수. strlen을 이용해서 제목의 길이를 일차적으로 입력받는다.
realtitleleng : 제목은 한글도 받을 수 있기 때문에 strlen을 사용할 때 한글은 3이 입력받는다는 것을 고려해야한다. 이 고려한 값을 저장하는 변수가 realtitleleng이다.*/

void SearchVideo(vptr n, int *count)
{
	getc(stdin);
	int num;
	//애초에 비디오가 등록되어있지 않으면 비디오가 없다고 출력한다.
	if(n == NULL)
	{
		printf("현재 등록된 비디오가 없습니다.\n");
		return;
	}
	char find[30];
	printf("찾는 ISBN 입력\n입력 : ");
	gets(find);
	if(CheckISBN(find)==1)
	{
	//ISBN의 형태가 맞는지 확인하는 함수를 통해 ISBN형태가 올바를 때만 진행하고 그렇지 않을 경우 잘못되었음을 출력하고 함수를 종료한다.
	}
	else
	{
		printf("입력 양식이 잘못되었습니다.\n");
		return;
	}
	for(num = 0; num < *count; num++)
	{
	//찾는 ISBN이 있는지 기존 Vlist에 저장된 비디오의 ISBN과 비교해본다. 있을 경우 그 비디오의 정보를 출력하고, 없을 경우 없다고 출력한다.
		if(strcmp(find,n[num].ISBN)==0)
		{
			printf("------------------------\n");
			printf("-> ISBN: %s\n",n[num].ISBN);
			printf("-> 타이틀: %s\n",n[num].title);
			if(n[num].genre == 1)
			{
				printf("-> 장르: 액션\n");
			}
			else if(n[num].genre == 2)
			{
				printf("-> 장르: 코믹\n");
			}
			else if(n[num].genre == 3)
			{
				printf("-> 장르: SF\n");
			}
			else if(n[num].genre == 4)
			{
				printf("-> 장르: 로맨틱\n");
			}
			printf("------------------------\n");
			return;
		}
		else
		{
			if(num == *count-1)
			{
				printf("해당하는 ISBN을 갖는 비디오가 존재하지 않습니다.\n");
			}
		}
	}
}
/* SearchVideo는 비디오가 등록되어있는  목록 내에 검색한 ISBN을 가진 비디오가 있는지 확인하고 있으면 비디오에 대한 정보를 출력해주는 함수이다.
n : 메인함수에서 비디오의 정보를 저장하는 구조체의 배열인 Vlist의파라미터이다.
count : Vlist의 개수를 알려주는 Vlist_count의 파라미터이다.
num : for문을 사용하기 위해 사용하는 변수이다.
find : 입력하는 ISBN을 받고 이를 find에 임시로 저장하여 Vlist에 저장된 비디오들의 ISBN과 비교하기 위해 쓰는 변수이다. */
void RentVideo(vptr v, int *vcount, mptr m, int *mcount,rptr* r, vlptr *vl)
{
 	getc(stdin);
	if(v == NULL)
	{
		// Vlist가 애초에 값이 없을때 대여할 비디오가 없다고 출력
		printf("현재 등록된 비디오가 없습니다.\n");
		return;
	}
	if(m == NULL)
	{
		// Clist가 애초에 값이 없을때 대여할 비디오가 없다고 출력
		printf("현재 등록된 회원이 없습니다.\n");
		return;
	}
	char ISBN[30];
	int num;
	int vnum;
	int mnum;
	char id[30];
	char date[30];
	vlptr vlcheck = *vl;
	vlptr vlpnew;
	rptr check = *r;
	rptr pnew;
	printf("대여 비디오의 ISBN을 입력해주세요.\n입력) ");
	gets(ISBN);
	if(CheckISBN(ISBN)==1)
	{
		//ISBN의 꼴이 올바른지 확인하는 CheckISBN으로 알맞은 형식이 입력되었나 확인.
	}
	else
	{
		printf("입력 양식이 잘못되었습니다.\n");
		return;
	}
	for(num = 0; num < *vcount; num++)
	{
		//입력받은 ISBN과 기존의 배열에 저장되어있던 비디오들의 ISBN과 비교해서 해당하는 ISBN이 존재하는지 확인 후 있으면 함수를 이어가고 없으면 없다고 출력 후 함수 종료.
		if(strcmp(ISBN,v[num].ISBN) == 0)
		{
			vnum = num; // 이때 몇 번째 비디오가 이 ISBN과 같은지를 vnum에 임시로 저장해둔다.
			break;
		}
		else
		{
			if(num == *vcount-1)
			{
				printf("해당하는 ISBN이 존재하지 않습니다.\n");
				return;
			}
		}
	}
	if(*r != NULL)
	//현재 대여상태를 알려주는 Rlist의 파라미터인 r을 이용해서 비디오가 대여상태인지 아닌지 확인.
	{
		while(check->link != NULL)
		{
			if(check->vnum == vnum)
			{
				printf("현재 이 비디오는 대여중입니다.\n");
				return;
			}
			check = check->link;
		}
		if(check->vnum == vnum)
		{
			printf("현재 이 비디오는 대여중입니다.\n");
			return;
		}
	}
	printf("대여가 가능합니다. 대여 과정을 진행합니다.\n");
	printf("대여할 고객의 ID를 적어주세요.\n입력: ");
	gets(id);
	for(num=0;num<*mcount;num++)
	{
		//id를 받아서 현재 저장되어있는 회원정보와 비교.
		if(strcmp(m[num].id,id)==0)
		{
			mnum = num; // 몇번 째 배열의 회원정보와 일치하는지 번째를 mnum에 저장.
			break;
		}
		else
		{
			if(num == *mcount-1)
			{
				printf("가입되어있지 않은 ID 입니다.\n");
				return;
			}
		}
	}
	printf("대여 날짜를 입력해주세요. (yyyy-mm-dd)\n입력: ");
	gets(date);
	//날짜의 입력을 형식에 맞춰 받도록함. 형식과 틀릴 경우 함수를 종료.
	if(strlen(date)!=10)
	{
		printf("입력 형식이 잘못되었습니다.\n날짜의 형식은 (yyyy-mm-dd)입니다.\n");
		return;
	}
	if(date[4] != '-' || date[7] != '-')
	{
		printf("입력 형식이 잘못되었습니다.\n날짜의 형식은 (yyyy-mm-dd)입니다.\n");
		return;
	}
	for(num = 0; num < 10; num++)
	{
		if(num != 4 && num != 7)
		{
			if(date[num] >= '0' && date[num] <='9')
			{
			}
			else
			{
				printf("입력 형식이 잘못되었습니다.\n날짜의 형식은 (yyyy-mm-dd)입니다.\n");
				return;
			}
		}
	}
	// 모든 경우를 만족시킬 때, 새 링크에 이 값을 저장 후 맨 끝 링크에 이를 저장해줌.
	pnew=(rptr)malloc(sizeof(Rent));
	if(*vl == NULL)
	{
		*vl=(vlptr)malloc(sizeof(Videolog));
		(*vl)->mnum = mnum;
		(*vl)->vnum = vnum;
		strcpy((*vl)->date,date);
	}
	else
	{
		vlpnew = (vlptr)malloc(sizeof(Videolog));
		while(vlcheck->link != NULL)
		{
			vlcheck = vlcheck->link;
		}
		vlcheck->link = vlpnew;
		vlpnew->mnum = mnum;
		vlpnew->vnum = vnum;
		vlpnew->link = NULL;
		strcpy(vlpnew->date,date);
	}
	if(*r == NULL)
	{
		*r=(rptr)malloc(sizeof(Rent));
		(*r)->mnum = mnum;
		(*r)->vnum = vnum;
		strcpy((*r)->date,date);
	}
	else
	{
		pnew=(rptr)malloc(sizeof(Rent));
		check->link = pnew;
		pnew->mnum = mnum;
		pnew->vnum = vnum;
		pnew->link = NULL;
		strcpy(pnew->date,date);
	}
	printf("대여가 완료되었습니다.\n");
}
/* RentVideo는 비디오를 대여하기 위해서 사용하는 함수이다. 비디오를 대여한 기록을 남기기 위해서 Rlist와 Vllist 또한 받는다. 기존의 Clist,Vlist는 배열이었지만, Rlist와 VLlist는 linked list이다. Rlist와 VLlist는 대여 기록을 저장하는 리스트인데, Rlist는 반납 시 대여 기록이 사라지며 현재의 대여 상태만 기록하게 된다. 반면 VLlist는 모든 기록을 남겨두기 때문에 대여 기록을 남길 수 있다.
m : 회원들의 정보를 저장해두는 배열 Clist의 파라미터
mcount : Clist의 크기를 나타내는 변수 Clist_count 의 파라미터
v : 비디오의 정보를 저장해두는 배열 Vlist의 파라미터
vcount : Vlist의 크기를 나타내는 변수 Vlist_count 의 파라미터
r : 현재의 대여상태를 저장하는 linked list Rlist의 파라미터
vl : 모든 대여상태를 저장하는 linked list VLlist의 파라미터
ISBN : 대여할 비디오의 ISBN의 값을 입력받아 비교하는 변수
num : for문을 사용하기 위해 쓰는 변수
vnum : r 과 vl에 저장할 값. 몇 번째 비디오가 대여되었는지 기록 
mnum : r 과 vl에 저장할 값. 몇 번째 고객이 대여를 했는지 기록
id : 대여하는 사람의 아이디를 확인하기 위해 쓰는 변수.
date : r 과 vl에 저장할 대여날짜
pnew : r의 linked list로 저장하기 위해 써야하는 값. 이곳에 새로 메모리를 할당하고 맨 마지막 link에 이어붙인다.
check : check를 통해 리스트의 맨 끝으로 감
vlpnew : vl의 linked list로 pnew와 기능이 같다.
vlcheck : vl의check변수*/

void ReturnVideo(vptr v, int *vcount, rptr* r)
{
	getc(stdin);
	int num;
	char ISBN[30];
	int checknum;
	rptr check = *r;
	rptr freenode;
	if(*r == NULL)
	{
		printf("현재 대여상태에 있는 비디오가 존재하지 않습니다.\n");
		return;
		//대여된 비디오가 없으면 없다고 출력 후 함수 종료.
	}
	printf("반납 비디오 ISBN을 입력해주세요.\n입력 : ");
	gets(ISBN);
	
	if(CheckISBN(ISBN) ==1)
	{
			//입력받은 ISBN의 꼴이 알맞은지 확인
	}
	else
	{
		printf("입력 형식이 잘못되었습니다.\n");
		return;
	
	
	}
	for(num = 0; num < *vcount; num++)
	{
		// ISBN이 있는지 확인하고 없으면 없다고 출력 후 종료. 있으면 그 비디오가 몇번째인지 checknum에 저장 후 다음 진행
		if(strcmp(ISBN,v[num].ISBN) == 0)
		{
			checknum = num;
			break;
		}
		else
		{
			if(num == *vcount-1)
			{
				printf("해당하는 ISBN은 존재하지 않습니다.\n");
				return;
			}
		}
	}
	// 대여했던 기록의 노드를 free하면서 반납이 완료되었음을 출력하는 과정
	if((*r)->link == NULL)
	{
		free(*r);
		*r = NULL;
		printf("반납이 완료되었습니다.\n");
		return;
	}
	if((*r)->vnum == checknum)
	{
		
		*r=(*r)->link;
		free(check);
		printf("반납이 완료되었습니다.\n");
		return;
	}
		
	while(check->link != NULL)
	{
		if(check->link->vnum == checknum)
		{
			freenode=check->link->link;
			free(check->link);
			check->link = freenode;
			printf("반납이 완료되었습니다.\n");
			return;
			
		
		}
		else
		{
			check = check->link;
			if(check->link == NULL)
			{
				printf("해당 ISBN은 대여되지 않은 비디오의 ISBN입니다.\n");
			}
		}
	}	
}
/*ReturnVideo는 대여한 비디오를 반납하는 함수이다. 이때 모든 비디오 대여기록을 기록하는 VLlist는 사용될 필요가 없으므로 사용하지 않고 Rlist만을 사용한다. 
v : 비디오를 저장하는 Vlist의 파라미터
vcount : Vlist의 배열의 개수를 알려주는 변수 Vlist_count의 파라미터
r : Rlist의 파라미터. 대여 기록을 저장하는 linked list
num : for문을 사용하기 위해 쓰는 변수.
ISBN : 반납할 ISBN을 임시로 저장하는 함수
checknum : ISBN들을 비교할때 몇번째 배열의 ISBN과 입력받은 ISBN이 일치하는지 그 몇 번째인지를 저장하는 변수.
check : free를 위해 사용,linked list를 들어갈 때 사용.
freenode : free를 위해 사용.*/

void RentalCustomerSearch(vptr v, int *vcount, mptr m,int *mcount,vlptr* vl)
{
	getc(stdin);
	if(*vl == NULL)
	{	
		printf("현재 아무런 대여 기록이 존재하지 않습니다.\n");
		return ;
	}
	int num;
	int vnum;
	char ISBN[30];
	int check=0;
	vlptr vlog = *vl;
	printf("ISBN을 입력해주세요.\n입력 : ");
	gets(ISBN);
	if(CheckISBN(ISBN) == 1)
	{
		//받은 ISBN의 양식 검사
	}
	else
	{
		printf("양식이 잘못되었습니다.\n");
		return;
	}
	for(num=0;num<*vcount;num++)
	{
		if(strcmp(ISBN,v[num].ISBN)==0)
		{
			vnum = num; // ISBN이 존재할 경우 이 ISBN이 몇번째인지 vnum에 저장
			break;
		}
		else
		{
			if(num == *vcount-1)
			{
				printf("해당 ISBN은 존재하지 않습니다.\n");
				return;
			}
		}
	}
	while(vlog != NULL) // linked list 사용하기 위해 vlog사용
	{
		if(vlog->vnum == vnum) // vnum과 vlong->num이 일치할때만 정보 출력 = 그 비디오에 대해서 정보를 출력
		{
			printf("대여일 : %s\n",vlog->date);
			printf("----------------------------\n");
			for(num=0;num<*mcount;num++)
			{
				if(vlog->mnum == num)
				{
					printf("->ID : %s\n",m[num].id);
					printf("->이름 : %s\n",m[num].name);
					printf("->전화번호 : %s\n",m[num].phone);
				}
			}
			printf("----------------------------\n");
			vlog = vlog->link;
			check = 1; //한번이라도 출력되었으면 대여한 적이 있는 것임 -> check = 1
		}
		else
		{
			vlog = vlog->link;
			if(vlog == NULL)
			{
				//없을 경우 계속 넘기다가 리스트가 끝나면 대여기록이 있었는가 없었는가 확인.
				if(check == 0)
				{
					printf("대여 기록이 없습니다.\n");
				} 
				return;
			}
		}
	}

	printf("조회를 완료하였습니다.\n");



}
/*RentalCustomerSearch는 한 비디오를 대여한 기록을 전부 살펴보는 함수이다. 이 때에는 모든 대여기록을 기록해둔 VLlist를 이용한다.
v : 비디오의 정보를 담은 Vlist의 파라미터
vcount : Vlist_count의 파라미터
m : 고객정보를 담은 Clist의 파라미터
mcount : Clist_count의 파라미터
vl : VLlist의 파라미터
num : for문을 쓰기 위해 사용
vnum : 몇번째 비디오가 쓰였는지 확인하기 위한 변수
ISBN : ISBN을 비교하기 위해 입력받은 ISBN을 저장해두는 변수
check : 대여기록이 있나 없나 확인하기 위해 쓰는 변수
vlog : linked list를 사용하기 위해서 쓰는 변수 */

void Exit(vptr *v, mptr *m, rptr* r, vlptr* vl)
{
	getc(stdin);
	free(*v);
	free(*m);
	rptr preR;
	rptr R = *r;
	if((*r) == NULL || (*r)->link == NULL)
	{
		free(*r);
	}
	else
	{
		while(R->link != NULL)
		{
			preR=R->link;
			free(R);
			R=preR;
		}
	}
	vlptr preVl;
	vlptr Vl = *vl;
	if(*vl == NULL || (*vl)->link == NULL)
	{
		free(*vl);
	}
	else
	{
		while(Vl->link != NULL)
		{
			preVl = Vl->link;
			free(Vl);
			Vl = preVl;
		}
	}

}
//Exit는 프로그램을 종료하려는 과정에서, 배열과 링크드 리스트를 전부 free해주는 과정이다.
void main()
{
	printf("_________ 메  뉴______________ \n");
	printf(" 1. 신규가입\n");
	printf(" 2. 고객검색\n");
	printf("_______________________________\n");
	printf(" 3. 비디오 등록\n");
	printf(" 4. 비디오 검색\n");
	printf("_______________________________\n");
	printf(" 5. 비디오 대여\n");
	printf(" 6. 비디오 반납\n");
	printf("_______________________________\n");
	printf(" 7. 비디오 대여고객 전체 조회\n");
	printf(" 8. 종료\n");
	printf("_______________________________\n");
	char command;
	mptr Clist=NULL;
	vptr Vlist=NULL;
	vlptr VLlist=NULL;
	rptr Rlist=NULL;
	int Clist_count=0;
	int Vlist_count=0;
	int VLlist_count=0;
	while(1)
	{
		if(command == '8')//command가 8일경우 while문을 나가고 프로그램이 종료됨.
		{
			break;
		}
		printf("선택) ");
		scanf("%c",&command);

		switch(command)//command의 값에 따라 실행시키는 함수가 나뉨.
		{
		case '1':
			NewMember(&Clist,&Clist_count);
			break;
		case '2':
			MemberSearch(Clist,&Clist_count);
			break;
		case '3':
			RegisterVideo(&Vlist,&Vlist_count);
			break;
		case '4':
			SearchVideo(Vlist,&Vlist_count);
			break;
		case '5':
			RentVideo(Vlist,&Vlist_count,Clist,&Clist_count,&Rlist,&VLlist);
			break;
		case '6':
			ReturnVideo(Vlist,&Vlist_count,&Rlist);
			break;
		case '7':
			RentalCustomerSearch(Vlist,&Vlist_count,Clist,&Clist_count,&VLlist);
			break;
		case '8':
			Exit(&Vlist,&Clist,&Rlist,&VLlist);
			break;
		default:
			getc(stdin);
			printf("잘못된 명령입니다.\n1 부터 8 사이에 해당하는 명령을 입력해 주십시오.\n");
		}
	}
	printf("이용해 주셔서 고마워요~\n");

}
