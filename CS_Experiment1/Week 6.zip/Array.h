#ifndef _ARRAY_
#define _ARRAY_
#include<stdio.h>
using namespace std;
template<class T>
class Array{
protected:
	T *data;
	int len;

public:
	Array<T>::Array(int size)
	{
		if (size > 0)
		{
			data = new T[size];
			len = size;
		}
		else
		{
			cout << "Array bound error!" << endl;
		}
	}
	Array<T>::~Array()
	{
		delete(data);
	}
	int length()
	{
		return len;
	}
	T& operator[](int i)
	{
		static int tmp;
		if (i >= 0 && i <len)
		{
			return data[i];
		}
		else
		{
			cout << "Array bound error" << endl;
			return tmp;
		}
	}
	T operator[](int i) const
	{
		if (i >= 0 && i < len)
		{
			return data[i];
		}
		else
		{
			cout << "Array bound error" << endl;
			return 0;
		}
	}

	void print()
	{
		int i;
		cout << "[";
		for (i = 0; i<len; i++)
		{
			cout << data[i] << " ";
		}
		cout << "]" << endl;
	}

};

#endif
