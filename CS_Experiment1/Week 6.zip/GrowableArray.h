#include "Array.h"
#include <iostream>
using namespace std;
template <class T>
class GrowableArray:public Array<T>{
public:
	GrowableArray(int size) : Array<T>(size){}
	~GrowableArray(){}

	T& operator[] (int i)
	{
		static T tmp;
		if (i >= 0 && i < len)
		{
			return data[i];
		}
		else if (i >= len)
		{
			int j;
			T *temp;
			temp = new T[i * 2];
			for (j = 0; j < i; j++)
			{
				temp[j] = data[j];
			}
			
			for (j = len; j < i*2; j++)
			{
				temp[j] = 0;
			}
			len = j;
			delete[] data;	
			data = temp;
			return data[i];
		}
		else
		{
			cout << "Array bound error!" << endl;
			return tmp;
		}
	}
};