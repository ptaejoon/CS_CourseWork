#include<iostream>
#include<cstring>
using namespace std;

class Str
{
private:
	char *str;
	int len;
public:
	Str(int leng);
	Str(char *neyong);
	~Str();
	int length(void);
	char *contents(void);
	int compare(class Str a);
	int compare(char *a);
	void operator = (char *a);
	void operator = (class Str a);
};

Str::Str(int leng)
{
	str = new char[leng+1];
}
Str::Str(char *neyong)
{
	len = strlen(neyong);
	str = new char[len+1];
	strcpy(str, neyong);
}
Str::~Str()
{
	delete str;
}
int Str::length(void)
{
	return len;
}
char* Str::contents(void)
{
	return str;
}
int Str::compare(class Str a)
{
	return strcmp(str, a.contents());
}
int Str::compare(char *a)
{
	return strcmp(str, a);
}
void Str::operator = (char *a)
{
	if (strlen(a) > len)
	{
		delete str;
		str = new char[strlen(a) + 1];
		
	}
	strcpy(str, a);
	len = strlen(a);
}
void Str::operator = (class Str a)
{
	if (strlen(a.contents()) > len)
	{
		delete str;
		str = new char[strlen(a.contents()) + 1];
		
	}
	strcpy(str, a.contents());
	len = strlen(a.contents());
}
int main()
{
	Str a("I'm a girl");
	cout << a.contents();
	a = "I'm a boy\n";
	cout << a.contents();
	cout << a.compare("I'm a a") << endl;
	return 0;
}