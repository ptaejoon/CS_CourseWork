#include <stdlib.h>
#include "..\ExternDoc.h"
#include "..\UI\Zoom.h"
#include "..\UI\MsgView.h"
#include "..\Graphics\DrawFunc.h"
#include "..\Example\Example.h"

#define ERROR_NUMBER -1

//function prototype

static void drawDirect(CDC *pDC);
static void drawBuffered();

//Start of user code
#include <float.h>

typedef struct room{
	char down;
	char left;
}room;
room **maze;
int width;
int height=0;
/*****************************************************************
* function	: bool readFile(const char* filename)
* argument	: cons char* filename - filename to be opened
* return	: true if success, otherwise flase
* remark	: After read data file, phisycal view must be set;
*			  otherwise drawing will not be executed correctly.
*			  The window will be invalidated after readFile()
*			  returns true.
******************************************************************/

bool readFile(const char* filename){
	
	//start of the user code

	FILE* fp = fopen( filename, "r" );

	if( fp == NULL ) return false;
	char a = '1';
	int count=0,count2;
	int heightcount=0;
	int endflag = 0;
	
	while(fscanf(fp,"%c",&a) != EOF)
	{
		if(a == '\n')
			height++;
	}
	height /= 2;
	maze = (room **)malloc(sizeof(room *)*(height));
	fclose(fp);
	fp = fopen(filename,"r");
	while(a != '\n')
	{
		fscanf(fp,"%c",&a);
		count++;
	}
	
	width = (count-1)/2;
	

	while(1)
	{
		a = '1';
		count = 0;
		maze[heightcount] = (room *)malloc(sizeof(room)*width);
		while(a != '\n')
		{
			fscanf(fp,"%c",&a);
			maze[heightcount][count].left = a;
			count++;
			fscanf(fp,"%c",&a);
		}
		count = 0;
		fscanf(fp,"%c",&a);
		while(a != '\n')
		{
			
			if(fscanf(fp,"%c",&a) == EOF)
			{
				endflag = 1;
				break;
			}
			if(a == '\n')
				break;
			maze[heightcount][count].down = a;
			count++;
			fgetc(fp);
			
		}
		heightcount++;
		if(endflag == 1)
		{
			break;
		}
	}
	fclose( fp );
	setWindow(0,0,1000,1000,1);
	
	return true; //edit after finish this function
	//end of usercode
}

/******************************************************************
* function	: bool FreeMemory()
*
* remark	: Save user data to a file
*******************************************************************/
void freeMemory(){
	//start of the user code
	int count;
	for(count = 0; count < height; count++)
	{
		free(maze[count]);
	}
	free(maze);
	//end of usercode
}

/**************************************************************
* function	: bool writeFile(const char* filename)
*
* argument	: const char* filename - filename to be written
* return	: true if success, otherwise false
* remark	: Save user data to a file
****************************************************************/
bool writeFile(const char* filename){
	//start of the user code
	bool flag;
	flag = 0;

	return flag;
	//end of usercode
}

/************************************************************************
* fucntion	: void drawMain(CDC* pDC)
*
* argument	: CDC* pDC - device context object pointer
* remark	: Main drawing function. Called by CMFC_MainView::OnDraw()
*************************************************************************/
void drawMain(CDC *pDC){
	//if direct drawing is defined
#if defined(GRAPHICS_DIRECT)
	drawDirect(pDC);
	//if buffered drawing is defined
#elif defined(GRAPHICS_BUFFERED)
	drawBuffered();
#endif
}

/************************************************************************
* function	: static void drawDirect(CDC *pDC
*
* argument	: CDC* pDC - device context object pointer
* remark	: Direct drawing routines here.
*************************************************************************/
static void drawDirect(CDC *pDC){
	//begin of user code
	//Nothing to write currently.
	//end of user code
}

/***********************************************************************
* function	: static void drawBuffered()
*
* argument	: CDC* pDC -0 device object pointer
* remark	: Buffered drawing routines here.
************************************************************************/
static void drawBuffered(){
	//start of the user code
	//end of the user code

	int lineWidth = 0.01;
	int i,j;
	int x,y;
	//draw upper border
	DrawSolidBox_I(4,4*height,5,4*height+1,lineWidth,RGB(0,0,255),RGB(0,0,255));//���� ���� �� �𼭸�
	for(i=0;i<height;i++){ //����
		DrawSolidBox_I(4*i+5,4*height,4*i+8,4*height+1,lineWidth,RGB(0,0,255),RGB(0,0,255));
		DrawSolidBox_I(4*i+8,4*height,4*i+9,4*height+1,lineWidth,RGB(0,0,255),RGB(0,0,255));
	}
	for(i=0;i<height;i++){//��� ���� ���Ͽ� ���� ���� ���� �׸���
		DrawSolidBox_I(width*4+4,4*(height-i)-3,width*4+4+1,4*(height-i),lineWidth,RGB(0,0,255),RGB(0,0,255));
		DrawSolidBox_I(width*4+4,4*(height-i-1),height*4+4+1,4*(height-i)-3,lineWidth,RGB(0,0,255),RGB(0,0,255));

		for(j=0;j<width;j++){//���� ��ĭ�� �����鼭 ������ ��� �Ʒ��� ��� ���� ���θ� ������ ���� �𼭸��� �׷�������.
			if(maze[i][j].left == '|')
				DrawSolidBox_I(4*(j+1),4*(height-i)-3,4*j+5,4*(height-i),lineWidth,RGB(0,255,255),RGB(0,255,255));
			if(maze[i][j].down == '-')
				DrawSolidBox_I(4*j+5,4*(height-i-1),4*(j+2),4*(height-i)-3,lineWidth,RGB(255,0,0),RGB(255,0,0));
			DrawSolidBox_I(4*(j+1),4*(height-i-1),4*j+5,4*(height-i)-3,lineWidth,RGB(0,0,255),RGB(0,0,255));
		}
	}
}