#include <stdlib.h>
#include "..\ExternDoc.h"
#include "..\UI\Zoom.h"
#include "..\UI\MsgView.h"
#include "..\Graphics\DrawFunc.h"
#include "..\Example\Example.h"

#define ERROR_NUMBER -1

//function prototype

static void drawDirect(CDC *pDC);
static void drawBuffered();

//Start of user code
#include <float.h>

typedef struct room{
	char down;
	char left;
	int bv;
	int v;
}room;
room **maze;
int width;
int height=0;
int dfscheck=0;
int bfscheck = 0;

typedef struct visit{
	int height;
	int width;
	struct visit* link;
}visited;
visited *vcheck=NULL;
visited *poppin;
visited *front;
visited *rear;
visited *bfcheck = NULL;
/*****************************************************************
* function	: bool readFile(const char* filename)
* argument	: cons char* filename - filename to be opened
* return	: true if success, otherwise flase
* remark	: After read data file, phisycal view must be set;
*			  otherwise drawing will not be executed correctly.
*			  The window will be invalidated after readFile()
*			  returns true.
******************************************************************/

bool readFile(const char* filename){
	
	//start of the user code

	FILE* fp = fopen( filename, "r" );

	if( fp == NULL ) return false;
	char a = '1';
	int count=0,count2;
	int heightcount=0;
	int endflag = 0;

	while(fscanf(fp,"%c",&a) != EOF)
	{
		if(a == '\n')
			height++;
	}
	height /= 2;
	maze = (room **)malloc(sizeof(room *)*(height));
	fclose(fp);
	fp = fopen(filename,"r");
	while(a != '\n')
	{
		fscanf(fp,"%c",&a);
		count++;
	}

	width = (count-1)/2;


	while(1)
	{
		a = '1';
		count = 0;
		maze[heightcount] = (room *)malloc(sizeof(room)*width);
		while(a != '\n')
		{
			fscanf(fp,"%c",&a);
			maze[heightcount][count].left = a;
			count++;
			fscanf(fp,"%c",&a);
		}
		count = 0;
		fscanf(fp,"%c",&a);
		while(a != '\n')
		{
			
			if(fscanf(fp,"%c",&a) == EOF)
			{
				endflag = 1;
				break;
			}
			if(a == '\n')
				break;
			maze[heightcount][count].down = a;
			count++;
			fgetc(fp);
			
		}
		heightcount++;
		if(endflag == 1)
		{
			break;
		}
	}
	fclose( fp );
	setWindow(0,0,5*width,5*height,0);
	
	return true; //edit after finish this function
	//end of usercode
}

/******************************************************************
* function	: bool FreeMemory()
*
* remark	: Save user data to a file
*******************************************************************/
void freeMemory(){
	//start of the user code
	int count;
	for(count = 0; count < height; count++)
	{
		free(maze[count]);
	}
	free(maze);
	height = 0;
	width = 0;
	//end of usercode
}

/**************************************************************
* function	: bool writeFile(const char* filename)
*
* argument	: const char* filename - filename to be written
* return	: true if success, otherwise false
* remark	: Save user data to a file
****************************************************************/
bool writeFile(const char* filename){
	//start of the user code
	bool flag;
	flag = 0;

	return flag;
	//end of usercode
}

/************************************************************************
* fucntion	: void drawMain(CDC* pDC)
*
* argument	: CDC* pDC - device context object pointer
* remark	: Main drawing function. Called by CMFC_MainView::OnDraw()
*************************************************************************/
void drawMain(CDC *pDC){
	//if direct drawing is defined
#if defined(GRAPHICS_DIRECT)
	drawDirect(pDC);
	//if buffered drawing is defined
#elif defined(GRAPHICS_BUFFERED)
	drawBuffered();
#endif
}

/************************************************************************
* function	: static void drawDirect(CDC *pDC
*
* argument	: CDC* pDC - device context object pointer
* remark	: Direct drawing routines here.
*************************************************************************/
static void drawDirect(CDC *pDC){
	//begin of user code
	//Nothing to write currently.
	//end of user code
}
void dobfs()
{
	int lineWidth = 0.01;
	visited * temp;

	temp = (visited *)malloc(sizeof(visited));
	temp->height = 0;
	temp->width = 0;
	int count = 0;
	temp->link = NULL;
	if (bfcheck == NULL)
	{
		bfcheck = temp;
		rear = temp;
		front = bfcheck;
		maze[0][0].v = 1;
	}
	int bigx, bigy;
	int x, y;
	while (bfcheck->height != height - 1 || bfcheck->width != width - 1)
	{
		
		if (maze[bfcheck->height][bfcheck->width].down != '-')
		{
			if (!maze[bfcheck->height + 1][bfcheck->width].bv)
			{
				temp = (visited *)malloc(sizeof(visited));
				temp->height = bfcheck->height + 1;
				temp->width = bfcheck->width;
				maze[bfcheck->height + 1][bfcheck->width].bv = 1;
				rear->link = temp;
				rear = rear->link;
			}
		} // �Ʒ��� ��������
		if (bfcheck->height != 0)
		{
			if (maze[bfcheck->height - 1][bfcheck->width].down != '-')
			{
				if (!maze[bfcheck->height - 1][bfcheck->width].bv)
				{
					temp = (visited *)malloc(sizeof(visited));
					temp->height = bfcheck->height - 1;
					temp->width = bfcheck->width;
					maze[bfcheck->height - 1][bfcheck->width].bv = 1;
					rear->link = temp;
					rear = rear->link;
				}
			}

		} // ���� �ö󰡱�
		if (maze[bfcheck->height][bfcheck->width].left != '|')
		{
			if (!maze[bfcheck->height][bfcheck->width - 1].bv)
			{
				temp = (visited *)malloc(sizeof(visited));
				temp->height = bfcheck->height;
				temp->width = bfcheck->width - 1;
				maze[bfcheck->height][bfcheck->width - 1].bv = 1;
				rear->link = temp;
				rear = rear->link;
			}
		} // ���� ����
		if (bfcheck->width != width - 1)
		{
			if (maze[bfcheck->height][bfcheck->width + 1].left != '|')
			{
				if (!maze[bfcheck->height][bfcheck->width + 1].bv)
				{
					temp = (visited *)malloc(sizeof(visited));
					temp->height = bfcheck->height;
					temp->width = bfcheck->width + 1;
					maze[bfcheck->height][bfcheck->width + 1].bv = 1;
					rear->link = temp;
					rear = rear->link;
				}
			}
		} // ������ ����
		bfcheck = bfcheck->link;
	}
	bfcheck = front;
}
void dodfs()
{
	int lineWidth = 0.01;
	visited * temp;
	temp = (visited *)malloc(sizeof(visited));
	temp->height = 0;
	temp->width = 0;
	int count=0;
	temp->link = NULL;
	int workflag;
	int firstflag =0;
	if(vcheck == NULL)
	{
		vcheck = temp;
		maze[0][0].v = 1;
	}
	int bigx,bigy;
	int x,y;
	
	while(vcheck->height != height-1 || vcheck->width != width -1 )
	{
		
		workflag = 0;
		temp = (visited *)malloc(sizeof(visited));
		if(maze[vcheck->height][vcheck->width].down != '-')
		{
			if(!maze[vcheck->height+1][vcheck->width].v)
			{
				workflag = 1;
				temp->height = vcheck->height+1;
				temp->width = vcheck->width;
				maze[vcheck->height+1][vcheck->width].v = 1;
				temp->link = vcheck;
				vcheck=temp;
			}
		} // �Ʒ��� ��������
		if(!workflag)
		{
			if(vcheck->height != 0)
			{
				if(maze[vcheck->height-1][vcheck->width].down != '-')
				{
					if(!maze[vcheck->height-1][vcheck->width].v)
					{
						workflag = 1;
						temp->height = vcheck->height-1;
						temp->width = vcheck->width;
						maze[vcheck->height-1][vcheck->width].v = 1;
						temp->link = vcheck;
						vcheck=temp;
					}
				}
			}
		} // ���� �ö󰡱�
		if(!workflag)
		{	
			if(maze[vcheck->height][vcheck->width].left != '|')
			{
				if(!maze[vcheck->height][vcheck->width-1].v)
				{
					workflag = 1;
					temp->height = vcheck->height;
					temp->width = vcheck->width-1;
					maze[vcheck->height][vcheck->width-1].v = 1;
					temp->link = vcheck;
					vcheck=temp;
				}
			}
		} // ���� ����
		if(!workflag)
		{
			if(vcheck->width != width-1)
			{
				if(maze[vcheck->height][vcheck->width+1].left != '|')
				{
					if(!maze[vcheck->height][vcheck->width+1].v)
					{
						workflag = 1;
						temp->height = vcheck->height;
						temp->width = vcheck->width+1;
						maze[vcheck->height][vcheck->width+1].v = 1;
						temp->link = vcheck;
						vcheck=temp;
					}
				}
			} // ������ ����
		}
		if(!workflag)
		{
			temp = vcheck;
			vcheck = vcheck->link;
			if(firstflag == 0)
			{
				firstflag = 1;
				poppin = temp;
				poppin->link = NULL;
			}
			else
			{
				temp->link = poppin;
				poppin = temp;
			}
			
		}
	}
}
void dfs()
{
	int count,count2;
	dfscheck = 1;
	bfscheck = 0;
	if (vcheck == NULL)
	{
		for(count = 0; count <height; count++)
		{
			for(count2 = 0; count2 < width; count2++)
			{
				maze[count][count2].v = 0;
			}
		}
	
		dodfs();
	}

}
void bfs()
{
	bfscheck = 1;
	dfscheck = 0;
	int count, count2;
	if (bfcheck == NULL)
	{
		for (count = 0; count <height; count++)
		{
			for (count2 = 0; count2 < width; count2++)
			{
				maze[count][count2].bv = 0;
			}
		}
		dfs();
		bfscheck = 1;
		dfscheck = 0;
		dobfs();
	}
}

/***********************************************************************
* function	: static void drawBuffered()
*
* argument	: CDC* pDC -0 device object pointer
* remark	: Buffered drawing routines here.
************************************************************************/

static void drawBuffered() {
	//start of the user code
	//end of the user code
	double lineWidth = 0.01;
	int i, j;
	int x, y;
	int bigx;
	int bigy;
	int workwell = 0;
	visited* first;
	visited* temp;
	//draw upper border
	DrawSolidBox_I(4, 4 * height, 5, 4 * height + 1, lineWidth, RGB(0, 0, 255), RGB(0, 0, 255));//���� ���� �� �𼭸�
	for (i = 0; i < width; i++) { //����
		DrawSolidBox_I(4 * i + 5, 4 * height, 4 * i + 8, 4 * height + 1, lineWidth, RGB(0, 0, 255), RGB(0, 0, 255));
		DrawSolidBox_I(4 * i + 8, 4 * height, 4 * i + 9, 4 * height + 1, lineWidth, RGB(0, 0, 255), RGB(0, 0, 255));
	}
	for (i = 0; i < height; i++) {//��� ���� ���Ͽ� ���� ���� ���� �׸���
		DrawSolidBox_I(width * 4 + 4, 4 * (height - i) - 3, width * 4 + 4 + 1, 4 * (height - i), lineWidth, RGB(0, 0, 255), RGB(0, 0, 255));
		DrawSolidBox_I(width * 4 + 4, 4 * (height - i - 1), width * 4 + 4 + 1, 4 * (height - i) - 3, lineWidth, RGB(0, 0, 255), RGB(0, 0, 255));

		for (j = 0; j < width; j++) {//���� ��ĭ�� �����鼭 ������ ��� �Ʒ��� ��� ���� ���θ� ������ ���� �𼭸��� �׷�������.
			if (maze[i][j].left == '|')
				DrawSolidBox_I(4 * (j + 1), 4 * (height - i) - 3, 4 * j + 5, 4 * (height - i), lineWidth, RGB(0, 0, 255), RGB(0, 0, 255));
			if (maze[i][j].down == '-')
				DrawSolidBox_I(4 * j + 5, 4 * (height - i - 1), 4 * (j + 2), 4 * (height - i) - 3, lineWidth, RGB(0, 0, 255), RGB(0, 0, 255));
			DrawSolidBox_I(4 * (j + 1), 4 * (height - i - 1), 4 * j + 5, 4 * (height - i) - 3, lineWidth, RGB(0, 0, 255), RGB(0, 0, 255));
		}
	}
	if (dfscheck)
	{
		first = vcheck;
	
		while (vcheck->height != 0 || vcheck->width != 0)
		{

			temp = vcheck->link;
			if (temp->width > vcheck->width)
			{
				bigx = temp->width;
				x = vcheck->width;
			}
			else
			{
				bigx = vcheck->width;
				x = temp->width;
			}
			if (temp->height > vcheck->height)
			{
				bigy = temp->height;
				y = vcheck->height;
			}
			else
			{
				bigy = vcheck->height;
				y = temp->height;
			}
			DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(255, 0, 0), RGB(255, 0, 0));
			//|�׸�����
			//j�� width, i�� height
			vcheck = vcheck->link;

		}
		vcheck = first;
		first = poppin;
		while (poppin != NULL)
		{

			temp = poppin;
			poppin = poppin->link;
			if (temp->height != height - 1)
			{
				if (maze[temp->height + 1][temp->width].v)
				{
					if (maze[temp->height][temp->width].down != '-') {
						bigx = temp->width;
						x = temp->width;
						bigy = temp->height + 1;
						y = temp->height;
						DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(0, 255, 0), RGB(0, 255, 0));
					}
				}
			}
			if (temp->height != 0)
			{
				if (maze[temp->height - 1][temp->width].v)
				{
					if (maze[temp->height - 1][temp->width].down != '-') {
						bigx = temp->width;
						x = temp->width;
						bigy = temp->height;
						y = temp->height - 1;
						DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(0, 255, 0), RGB(0, 255, 0));
					}
				}
			}
			if (temp->width != width - 1)
			{
				if (maze[temp->height][temp->width + 1].v)
				{
					if (maze[temp->height][temp->width + 1].left != '|') {
						bigx = temp->width + 1;
						x = temp->width;
						bigy = temp->height;
						y = temp->height;
						DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(0, 255, 0), RGB(0, 255, 0));
					}
				}
			}
			if (temp->width != 0)
			{
				if (maze[temp->height][temp->width - 1].v)
				{
					if (maze[temp->height][temp->width].left != '|') {
						bigx = temp->width - 1;
						x = temp->width;
						bigy = temp->height;
						y = temp->height;
						DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(0, 255, 0), RGB(0, 255, 0));
					}
				}
			}
		}
		poppin = first;
	}
	if (bfscheck)
	{
		bfcheck = front;
		while (bfcheck != rear)
		{
			temp = bfcheck;
			bfcheck = bfcheck->link;
			if (temp->height != height - 1)
			{
				if (maze[temp->height + 1][temp->width].bv)
				{
					if (maze[temp->height][temp->width].down != '-') {
						bigx = temp->width;
						x = temp->width;
						bigy = temp->height + 1;
						y = temp->height;
						DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(0, 255, 0), RGB(0, 255, 0));
					}
				}
			}
			if (temp->height != 0)
			{
				if (maze[temp->height - 1][temp->width].bv)
				{
					if (maze[temp->height - 1][temp->width].down != '-') {
						bigx = temp->width;
						x = temp->width;
						bigy = temp->height;
						y = temp->height - 1;
						DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(0, 255, 0), RGB(0, 255, 0));
					}
				}
			}
			if (temp->width != width - 1)
			{
				if (maze[temp->height][temp->width + 1].bv)
				{
					if (maze[temp->height][temp->width + 1].left != '|') {
						bigx = temp->width + 1;
						x = temp->width;
						bigy = temp->height;
						y = temp->height;
						DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(0, 255, 0), RGB(0, 255, 0));
					}
				}
			}
			if (temp->width != 0)
			{
				if (maze[temp->height][temp->width - 1].bv)
				{
					if (maze[temp->height][temp->width].left != '|') {
						bigx = temp->width - 1;
						x = temp->width;
						bigy = temp->height;
						y = temp->height;
						DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(0, 255, 0), RGB(0, 255, 0));
					}
				}
			}
		}
		first = vcheck;
		while (vcheck->height != 0 || vcheck->width != 0)
		{
	
			temp = vcheck->link;
			if (temp->width > vcheck->width)
			{
				bigx = temp->width;
				x = vcheck->width;
			}
			else
			{
				bigx = vcheck->width;
				x = temp->width;
			}
			if (temp->height > vcheck->height)
			{
				bigy = temp->height;
				y = vcheck->height;
			}
			else
			{
				bigy = vcheck->height;
				y = temp->height;
			}
			DrawSolidBox_I(4 * x + 6, 4 * (height - bigy) - 2, 4 * bigx + 7, 4 * (height - y) - 1, lineWidth, RGB(255, 0, 0), RGB(255, 0, 0));
			vcheck = vcheck->link;

		}
		vcheck = first;
	}
}