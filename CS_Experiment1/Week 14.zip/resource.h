//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFC_Main.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MFC_MATYPE                  129
#define IDC_ZOOM                        130
#define ID_VIEW_FULLVIEW                32771
#define ID_VIEW_ZOOM                    32772
#define ID_TOOLS_TEST                   32773
#define ID_BUTTON32791                  32791
#define ID_32792                        32792
#define ID_32793                        32793
#define DFS                             32794
#define BFS                             32795
#define ID_DFS                          32796
#define ID_BFS                          32797
#define MENU_BFS                        32801
#define MENU_DFS                        32802
#define ID_INDICATOR_COORD              59200

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32803
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
