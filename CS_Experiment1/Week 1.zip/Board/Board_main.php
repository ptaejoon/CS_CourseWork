<?
 echo('<a href = "Board_write.php">게시판 쓰기</a>');
 //echo를 통해 html문을 출력해서 게시판 쓰기로 링크를 추가한다.
 echo('<br>');
 //echo를 통해 엔터를 입력
 echo('<a href = "Board_read.php">게시판 읽기</a>');
 //echo를 통해 게시판 읽기 링크를 만든다.
?>