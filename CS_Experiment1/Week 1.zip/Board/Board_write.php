<?
  echo("<h1>게시판 쓰기</h1>");
  //게시판 쓰기라는 문구를 출력
  $fp = fopen("data.txt","w");
  //작성할 txt파일 열기
	if($_POST[text])
	//post가 된 상태에서 form 내부에 "text"인 textarea에 내용이 존재하는 경우 if를 실행한다.
	{
		$fp=fopen("Data.txt","w");
		fwrite($fp,$_POST[text],strlen($_POST[text]));
		fclose($fp);
		//Data.txt를 열고 내용을 
		echo('<meta http-equiv="Refresh" content="0; URL=Board_main.php">');
	}
	echo('
		<form method = "post" name = "form" action="Board_write.php"> 
		<!-form 형태를 작성. textarea와 제출버튼, 리셋버튼을 만든다. -->
			<textarea rows="10%" cols="40%" name ="text"></textarea>
			<br>
			<input type="submit" value="등록하기" >
			<input type="reset" value="다시기입" >
		</form>
	');

	echo("<a href = 'Board_main.php'>되돌아 가기</a>"); // 메인으로 되돌아가는 버튼을 만든다.
 ?>