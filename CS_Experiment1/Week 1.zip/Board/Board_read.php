<?
  echo("<h1>게시판 읽기</h1>"); 
  //게시판 읽기 라는 문구를 출력
 ?>
<table border = 1 width = 60% height = 10%>
	<tr valign = center>
		<td>
		
			<?
				$filename = "Data.txt";
				$fp = fopen($filename,"r");
				//Data.txt파일을 읽기 전용으로 연다.
				if(filesize($filename) != 0)
				{
					$data = fread($fp,filesize($filename));
					//파일에 읽을 내용이 존재한다면 data라는 변수에 Data.txt의 내용을 저장한다.
				}
				else
				{
					//읽을 내용이 존재하지 않으면 아예 아무것도 저장하지 않는다.
				}
				echo($data);
				//데이터가 저장된 data변수를 출력
				fclose($fp);
				//작업 후 열었던 파일 닫기
			?>

		<!--테이블을 만들어서 쓰인 글에 테두리를 만들어줌 -->
		</td>
	</tr>
</table>
<?
  echo("<br>");
  echo('<a href = "Board_main.php">되돌아 가기</a>');
 ?>
  <!-- 되돌아가기 버튼을 만들어준다. 이 링크를 이용하면 메인 화면으로 돌아간다. --> 