#include<stdio.h>
void F1();
void F2(const char *);
char* F3(int);
extern int testCaseNum;
extern int currentCase;