#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
#include<string.h>
#include "MyHeader.h"

typedef struct node
{
	int count;
	int **line;
}CASES;

CASES *testCases;

char *resultString;
int testCaseNum;
int currentCase;

void F1(void)
{
	free(resultString);
	resultString = (char*)malloc(sizeof(char) * 20);
	testCaseNum = 0;
	currentCase = 0;

}
void F2(const char *filename)
{
	FILE *fp;
	int count;
	int count1;
	fp = fopen(filename, "r");
	fscanf(fp, "%d", &testCaseNum);
	testCases = (CASES *)malloc(sizeof(testCases)*testCaseNum);
	for (count = 0; count < testCaseNum; count++)
	{
		fscanf(fp, "%d", &(testCases[count].count));
		testCases[count].line = (int **)malloc(sizeof(int*)*testCases[count].count);
		for (count1 = 0; count1 < testCases[count].count; count1++)
		{
			testCases[count].line[count1] = (int *)malloc(sizeof(int) * 2);
			fscanf(fp, "%d %d", &(testCases[count].line[count1][0]), &(testCases[count].line[count1][1]));
		}
	}
	fclose(fp);
}
char* F3(int number)
{
	int NoTree=0;
	int count, count1;
	int yes = 0;
	int* arr;
	int n=0;
	int a;
	arr = (int*)calloc(sizeof(int),testCases[number].count *2);
	for (count = 0; count < testCases[number].count-1; count++)
	{
		
		for (count1 = count+1; count1 < testCases[number].count; count1++)
		{
			if (testCases[number].line[count][1] == testCases[number].line[count1][1])
			{
				NoTree = 1;
			}
		}
	}
	for (count = 0; count < testCases[number].count; count++)
	{
		yes = 0;
		for (count1 = 0; count1 < testCases[number].count; count1++)
		{
			if (testCases[number].line[count][0] == testCases[number].line[count1][1])
			{
				break;
			}
			else if (testCases[number].count - 1 == count1)
			{
				yes = 1;
			}
		}
		if (yes == 1)
		{
			break;
		}
	}
	for (count = 0; count < testCases[number].count; count++)
	{
		arr[testCases[number].line[count][0]] = testCases[number].line[count][1];
	}
	for (count = 1; count < testCases[number].count + 1; count++)
	{
		a = arr[count];
		n = 0;
		while (n < testCases[number].count)
		{
			a = arr[a];
			n++;
		}
		if (a != 0)
		{
			NoTree = 1;
			break;
		}
	}

	number++;
	if (NoTree == 0 && yes == 1)
	{
		sprintf(resultString, "Case %d is a tree", number);
		return resultString;
	}
	else
	{
		sprintf(resultString, "Case %d is not a tree", number);
		return resultString;
	}
	


}