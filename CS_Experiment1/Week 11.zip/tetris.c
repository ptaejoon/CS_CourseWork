﻿#include "tetris.h"

static struct sigaction act, oact;

int main(){
	int exit=0;

	initscr();
	noecho();
	keypad(stdscr, TRUE);	

	srand((unsigned int)time(NULL));

	while(!exit){
		clear();
		score = 0;
		switch(menu()){
		case MENU_PLAY: play(); break;
		case MENU_RANK: rank(); break;
		case MENU_RECOMMEND: recommendedPlay(); break;
		case MENU_EXIT: exit=1; break;
		default: break;
		}
	}

	endwin();
	system("clear");
	return 0;
}

void InitTetris(){
	int i,j;

	for(j=0;j<HEIGHT;j++)
		for(i=0;i<WIDTH;i++)
			field[j][i]=0;

	nextBlock[0]=rand()%7;
	nextBlock[1]=rand()%7;
	nextBlock[2]=rand()%7;
	blockRotate=0;
	blockY=-1;
	blockX=WIDTH/2-2;
	score=0;	
	gameOver=0;
	timed_out=0;

	DrawOutline();
	DrawField();
	DrawBlockWithFeatures(blockY,blockX,nextBlock[0],blockRotate);
	DrawNextBlock(nextBlock);
	PrintScore(score);
}

void DrawOutline(){	
	int i,j;
	/* 블럭이 떨어지는 공간의 태두리를 그린다.*/
	DrawBox(0,0,HEIGHT,WIDTH);

	/* next block을 보여주는 공간의 태두리를 그린다.*/
	move(2,WIDTH+10);
	printw("NEXT BLOCK");
	DrawBox(3,WIDTH+10,4,8);

	/* score를 보여주는 공간의 태두리를 그린다.*/
	move(9,WIDTH+10);
	DrawBox(10,WIDTH+10,4,8);
	
	move(16,WIDTH+10);
	printw("SCORE");
	DrawBox(17,WIDTH+10,1,8);

	
}

int GetCommand(){
	int command;
	command = wgetch(stdscr);
	switch(command){
	case KEY_UP:
		break;
	case KEY_DOWN:
		break;
	case KEY_LEFT:
		break;
	case KEY_RIGHT:
		break;
	case ' ':	/* space key*/
		/*fall block*/
		break;
	case 'q':
	case 'Q':
		command = QUIT;
		break;
	default:
		command = NOTHING;
		break;
	}
	return command;
}

int ProcessCommand(int command){
	int ret=1;
	int drawFlag=0;
	switch(command){
	case QUIT:
		ret = QUIT;
		break;
	case KEY_UP:
		if((drawFlag = CheckToMove(field,nextBlock[0],(blockRotate+1)%4,blockY,blockX)))
			blockRotate=(blockRotate+1)%4;
		break;
	case KEY_DOWN:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)))
			blockY++;
		break;
	case KEY_RIGHT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX+1)))
			blockX++;
		break;
	case KEY_LEFT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX-1)))
			blockX--;
		break;
	default:
		break;
	}
	if(drawFlag) DrawChange(field,command,nextBlock[0],blockRotate,blockY,blockX);
	return ret;	
}

void DrawField(){
	int i,j;
	for(j=0;j<HEIGHT;j++){
		move(j+1,1);
		for(i=0;i<WIDTH;i++){
			if(field[j][i]==1){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(".");
		}
	}
}


void PrintScore(int score){
	move(18,WIDTH+11);
	printw("%8d",score);
}

void DrawNextBlock(int *nextBlock){
	int i, j;
	for( i = 0; i < 4; i++ ){
		move(4+i,WIDTH+13);
		for( j = 0; j < 4; j++ ){
			if( block[nextBlock[1]][0][i][j] == 1 ){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
	for( i=0; i< 4; i++) {
		move(11+i,WIDTH+13);
		for( j = 0; j< 4; j++)
		{
			if(block[nextBlock[2]][0][i][j] == 1){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}
}

void DrawBlock(int y, int x, int blockID,int blockRotate,char tile){
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			if(block[blockID][blockRotate][i][j]==1 && i+y>=0){
				move(i+y+1,j+x+1);
				attron(A_REVERSE);
				printw("%c",tile);
				attroff(A_REVERSE);
			}
		}

	move(HEIGHT,WIDTH+10);
}

void DrawBox(int y,int x, int height, int width){
	int i,j;
	move(y,x);
	addch(ACS_ULCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_URCORNER);
	for(j=0;j<height;j++){
		move(y+j+1,x);
		addch(ACS_VLINE);
		move(y+j+1,x+width+1);
		addch(ACS_VLINE);
	}
	move(y+j+1,x);
	addch(ACS_LLCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_LRCORNER);
}

void play(){
	int command;

	clear();
	act.sa_handler = BlockDown;
	sigaction(SIGALRM,&act,&oact);
	InitTetris();
	do{
		if(timed_out==0){
			alarm(1);
			timed_out=1;
		}

		command = GetCommand();
		if(ProcessCommand(command)==QUIT){
			alarm(0);
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-bye!!");
			refresh();
			getch();

			return;
		}
	}while(!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
}

char menu(){
	printw("1. play\n");
	printw("2. rank\n");
	printw("3. recommended play\n");
	printw("4. exit\n");
	return wgetch(stdscr);
}

int CheckToMove(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	// user code
	int i,j;
	for(i = 0; i < 4; i++)
	{
		for(j=0; j <4; j++)
		{
			if(block[currentBlock][blockRotate][i][j] == 1)
			{
				if(i+blockY>=HEIGHT) return 0;
				if(j+blockX>=WIDTH || j+blockX<0) return 0;
				if(field[i+blockY][j+blockX]==1)return 0;
			}
		}
	}
	return 1;
}

void DrawChange(char f[HEIGHT][WIDTH],int command,int currentBlock,int blockRotate, int blockY, int blockX){
	int exblockX,exblockY;
	int exblockRotate = blockRotate;
	int i,j;
	DrawField();
	DrawBlockWithFeatures(blockY,blockX,currentBlock,blockRotate);
	// user code
	
}//블록을 한 칸 내림
 // 예전 블록을 지우고 다시 그려줌
void BlockDown(int sig){
	if(CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)){
		blockY++;
		DrawChange(field, KEY_DOWN,nextBlock[0],blockRotate,blockY,blockX);
	}
	else
	{
		if(blockY == -1) gameOver=1;
		score += AddBlockToField(field,nextBlock[0],blockRotate,blockY,blockX);	
		score+=DeleteLine(field);
		nextBlock[0] = nextBlock[1];
		nextBlock[1] = nextBlock[2];
		nextBlock[2] = rand()%7;
		maxV=0;
		save=0;
		checky = 0;
		nodewhere = 0;	
		recommend(RecHead,1,field,0);
		blockX=WIDTH/2-2;
		blockY=-1;
		blockRotate=0;
		DrawField();
		DrawNextBlock(nextBlock);
		PrintScore(score);
	}
	timed_out=0;
	// user code
}//true일때 이 함수 종료하면 프로그램이 종료
 //매초마다 블록을 한칸씩 내림
int AddBlockToField(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	// user code
	int i,j;
	int touched=0;
	for(i=0; i< 4; i++)
	{
		for(j=0; j<4; j++)
		{
			if(block[currentBlock][blockRotate][i][j] == 1)
			{
				f[blockY+i][blockX+j]=1;
			}
		}
	}
	for(i = 0; i < 4; i++)
	{
		for(j=3; j >= 0; j--)
		{
			if(block[currentBlock][blockRotate][j][i] == 1)
			{
				if(j+blockY+1 == 22)
				{
					touched++;
					break;
				}
				if(f[j+blockY+1][blockX+i] == 1)
				{
					touched++;
					break;
				}
				break;
			}
		}
		
	}


	return touched * 10;
}
 // 블록을 필드에 쌓는다
 // 블록을 field에 쌓음
int DeleteLine(char f[HEIGHT][WIDTH]){
	// user code
	int i,j =0;
	int flag=0;
	int line=0;
	int changei;
	for(i=0;i<HEIGHT;i++)
	{
		flag = 0;
		for(j=0; j<WIDTH;j++)
		{
			if(f[i][j] == 1)
			{
				if(j == WIDTH-1)
				{
					flag = 1;
					line++;
				}
			}
			else
			{
				break;
			}
		}
		if(flag == 1)
		{
			for(changei=i;changei>0;changei--)
			{
				for(j=0; j<WIDTH; j++)
				{
					f[changei][j] = f[changei-1][j];
				}
			}
		} 
	} 
	return line*line*100;
}//완전한 line이 있을 경우 지워주고 검수를 갱신한 뒤 출력
 // 채워진 가로줄 삭제
//오늘은 여기까지

void DrawShadow(int y, int x, int blockID,int blockRotate)
{
	
	while(CheckToMove(field,blockID,blockRotate,++y,x));
	DrawBlock(--y,x,blockID,blockRotate,'/');
}

void createRankList(){
	// user code
	FILE* fp;
	int i;
	fp = fopen("rank.txt","r");
	if(fp == NULL)
	{
		nodesize = 0;
		return;
	}
	if(node != NULL)
	{
		free(node);
	}
	fscanf(fp,"%d",&nodesize);
	node = (Node *)malloc(sizeof(Node)*nodesize);
	for(i = 0; i < nodesize; i++)
	{
		fscanf(fp,"%s %d",node[i].name,&(node[i].score));
	}
	fclose(fp);
}

void rank(){
	// user code
	clear();
	noecho();
	int rx=1,ry=0,count;
	char x[5],y[5];
	int num=1;
	char findname[NAMELEN];
	int nameflag=0;
	int delnum=5000;
	printw("1. list ranks X to Y\n");
	printw("2. list ranks by a specific name\n");
	printw("3. delete a specific rank\n");
		
	switch(wgetch(stdscr))
	{
		case '1' :
			// list ranks from X to y
			if(node == NULL)
			{
			createRankList();
			}
			echo();
			printw("X : ");
			
			scanw("%s",x);	
			if(x[0] < '0' || x[0] > '9')
			{
				rx = 1;
			}
			else
			{
				rx = x[0]-'0';
				while(x[num] != '\0')
				{
					rx *= 10;
					rx += x[num]-'0';
					num++;
				}
			
			}
			printw("Y : ");
			scanw("%s",&y);
			noecho();
			num = 1;
			if(y[0]<'0' || y[0] > '9')
			{
				ry = nodesize;
			}
			else
			{
				ry = y[0]-'0';
				while(y[num] != '\0')
				{
					ry *= 10;
					ry += y[num]-'0';
					num++;
				}
				
			}
			printw("	name	|   score \n");
			printw("--------------------------\n");
			if(rx >nodesize)
			{
				printw("search failure: no rank in the list\n");
				wgetch(stdscr);
				break;
			}
			if(rx >ry)
			{
				printw("search failure: no rank in the list\n");
				wgetch(stdscr);
				break;
			}
			for(count = rx-1; count<=ry-1; count++)
			{
				printw("%-16s|%d\n",node[count].name,node[count].score);
			}
			wgetch(stdscr);
			break;
		case '2' :
			if(node == NULL)
			{
				createRankList();
			}
			printw("Input the name : ");
			echo();
			scanw("%s",&findname);
			noecho();
			printw("	name    |   score \n");
			printw("--------------------------\n");
			for(count = 0; count < nodesize; count++)
			{
				if(!strcmp(node[count].name,findname))
				{
					printw("%-16s|%d\n",node[count].name,node[count].score);
					nameflag = 1;
				}
			}
			if(nameflag == 0)
			{
				printw("search failure: no name in the list\n");
			}
			wgetch(stdscr);
			// list ranks by a specific name
			break;
		case '3' :
			if(node == NULL)
			{
				createRankList();
			}
			printw("Input the rank : ");
			echo();
			scanw("%d",&delnum);
			noecho();
			if(delnum > nodesize)
			{
				printw("search failure: the rank not in the list\n");
				wgetch(stdscr);
				break;
			}
			else
			{
				for(count = delnum-1; count < nodesize-1; count++)
				{
					strcpy(node[count].name,node[count+1].name);
					node[count].score = node[count+1].score;
				}
				nodesize -= 1;
				writeRankFile();
				printw("Result : the rank deleted\n");
				wgetch(stdscr);
				break;
			}

			break;
	}	
}

void writeRankFile(){
	// user code
	int i;
	FILE *fp;
	fp=fopen("rank.txt","w");
	fprintf(fp,"%d\n",nodesize);
	for(i=0;i<nodesize;i++)
	{
		fprintf(fp,"%s %d\n",node[i].name,node[i].score);
	}
	fclose(fp);
		
	
}

void newRank(int score){
	// user code

	clear();
	createRankList();
	char name[16];
	int i;
	int position;
	printw("your name : ");
	echo();
	scanw("%s",name);
	noecho();
	
	if(nodesize == 0)
	{
		node = (Node*)malloc(sizeof(Node)*1);
		strcpy(node[nodesize].name,name);
		node[nodesize].score = score;
	}
	else
	{
	
		node = realloc(node,sizeof(Node)*(nodesize+1));
		strcpy(node[nodesize].name,name);
		node[nodesize].score = score;
		position = nodesize;
		for(i=0; i<nodesize; i++)
		{
			if(node[i].score < score)
			{
				position = i;
				break;
			}
		}
		if(position != nodesize)
		{
		
			for(i=nodesize; i>position; i--)
			{
				strcpy(node[i].name,node[i-1].name);
				node[i].score = node[i-1].score;
			}
			strcpy(node[position].name,name);
			node[position].score = score;
		}
	}
	nodesize += 1;
	writeRankFile();
}
/* typedef struct _RecNode{
    int lv, score;
    char f[HEIGHT][WIDTH];
    struct _RecNode *c[CHILDREN_MAX];
 }RecNode */
/* nextBlock[0]*/
void DrawRecommend(int y, int x, int blockID,int blockRotate)
{
	
	int rotation = (nodewhere)/10;
	int position = (nodewhere)%10;
	while(CheckToMove(field,nextBlock[0],rotation,++y,position));
	DrawBlock(--y,position,nextBlock[0],rotation,'R');
	// user code
}

int recommend(RecNode* root,int lv,char f[HEIGHT][WIDTH],int score){
	int max=0; // 미리 보이는 블럭의 추천 배치까지 고려했을 때 얻을 수 있는 최대 점수
	int count1,count2,count=0;
	int count3,count4,count5;
	int checkscore=score;
	root =(RecNode*)malloc(sizeof(RecNode));
	root->lv = lv;
	for(count1= 0; count1 < 22; count1++)
	{
		for(count2 = 0; count2 < 10; count2++)
		{
			root->f[count1][count2]=f[count1][count2];
		}
	}
	int noy = 0;
	count = 0;
	for(count1 = 0; count1 < 4; count1++/*회전*/)
	{
		for(count2 = 0; count2< 10; count2++/* 위치 */)
		{
			while(CheckToMove(root->f,nextBlock[lv-1],count1,++noy,count2));
			checkscore += AddBlockToField(root->f,nextBlock[lv-1],count1,--noy,count2);
			checkscore += DeleteLine(root->f);
				
			if(BLOCK_NUM > lv)
			{
				if(lv==1){
				savey = noy;		
				save = count;
				}
				recommend(root->c[count],lv+1,root->f,checkscore);
				
			}
			if(BLOCK_NUM == lv)
			{
				if(maxV < checkscore){
					maxV=checkscore; 
					nodewhere = save;
				}
				else if(max == checkscore)
				{
					if(checky < savey)
					{
						checky = savey;
						nodewhere = save;

					}
				}
			}
			noy = 0;
			checkscore = score;
			for(count3 = 0; count3 < 22; count3++)
			{
				for(count4 = 0; count4 < 10; count4++)
				{
					root->f[count3][count4] = f[count3][count4];
				}
			}
			
			count++;
				
			
		}	

	}
	
	// user code
}
void genetic(int sig)
{
	int A,B,C,D,E,F,G;
	float sum;
	int rotate=4;
	int wherex=10;
	int count,count2,count3,count4;
	int y=0;
	int bestx=0,besty=0,bestrotate=0;
	float max;
	int ff=0;

	int i=0,j=0;
	int Ay,Ccount;
	char copyfield[HEIGHT][WIDTH];
	char bestfield[HEIGHT][WIDTH];
	int Bflag;
	int xyxy;
	int startflag=0;
	int Fflag;
	if(!CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX))gameOver = 1;
	else{
	

	for(count = 0; count < rotate; count++)
	{
		for(count2=0; count2<wherex; count2++)
		{
			for(count3 = 0; count3 < HEIGHT; count3++)
			{
				for(count4 = 0; count4 <WIDTH; count4++)
				{
					copyfield[count3][count4] = field[count3][count4];
				}
			}
	/*	
			printw("rotate: %d x : %d A: %d B : %d C : %d D : %d E : %d F : %d G : %d MAX : %f y : %d bx : %d by : %d br : %d\n" ,count,count2,A,B,C,D,E,F,G,max,y,bestx,besty,bestrotate);
			
			*/
			
			y=0;
			
			while(CheckToMove(copyfield,nextBlock[0],count,++y,count2));
			y--;
					
			G = 0;
			for(count3 = 0; count3 < 4; count3++)
			{
				for(count4 = 0; count4 < 4; count4++)
				{
					if(block[nextBlock[0]][count][count3][count4]==1)
					{
						if(count3+y == 21)
						{
							G+=1;							
						}
					}
				}
			}
			E=0;
			for(count3 = 0; count3<4; count3++)
			{
				for(count4 = 0; count4<4; count4++)
				{
					if(block[nextBlock[0]][count][count3][count4]==1)
					{
						if(count4+count2 != 9)
						{
							if(field[count3+y][count4+count2+1] == 1)
							{
							
									E++;
								
							}
						}
						if(count4+count2 != 0)
						{
							if(field[count3+y][count4+count2-1] == 1)
							{
		
									E++;
								
							}
						}
						if(count3+y != 21)
						{
							if(field[count3+y+1][count4+count2] == 1)
							{
									E++;
							
							}
						}
						if(count3+y != 0)
						{
							if(field[count3+y-1][count4+count2] == 1)
							{
								if(count3+y != 0)
								{
									E++;
								}
							}
						}
					}
				}
			}
				

			F = 0;
			Fflag = 0;
			for(count3 = 0; count3 < 4; count3++)
			{
				for(count4 = 0; count4 < 4; count4++)
				{
					if(block[nextBlock[0]][count][count3][count4]==1)
					{
						
						if(count4+count2 == 0 || count4+count2 == 9)
						{
							F++;
						}/*
						if(count%2 == 1)
						{
							if(count4+count2-1 == 0)
							{
								F++;
								Fflag = 1;
							}
						}*/
	

						
					}
				}
			}
						
			B = 0;
			C = 0;
			AddBlockToField(copyfield,nextBlock[0],count,y,count2);
			for(count3 = 0; count3 < WIDTH; count3++)
			{
				Bflag = 0;
				Ccount = 0;
				for(count4=0;count4<HEIGHT;count4++)
				{
					if(copyfield[count4][count3] == 1)
					{
						Bflag = 1;
					}
					if(Bflag == 1)
					{
						Ccount++;
						if(copyfield[count4][count3] == 0)
						{
							B +=1;
							Ccount -= 1;
							C += Ccount;
							Ccount += 1;
						}
					}
				}
			}



			A = 0;
			for(count3 = 0 ; count3 < WIDTH; count3++)
			{
				Ay = 22;
				for(count4 = WIDTH-1;count4>0;count4--)
				{
					if(copyfield[count4][count3] == 1)
					{
						Ay = count4;
					}
				}
				A+=22-Ay;
			}
			D = 0;
			switch(DeleteLine(copyfield))
			{
				case 100:
					D = 1;
					
					break;
				case 400:
					
					D = 2;
					break;
				case 900 :
					
					D = 3;
					break;
				case 1600:
					
					D = 4;
					break;
				default:
					D = 0;
					break;
			}
			if(startflag == 0){
				startflag = 1;
				max = (-3.78)*(float)A+(-8.8)*(float)B+(-0.69)*(float)C+(9.2)*(float)D+(3.5)*(float)E+(2.7)*(float)F+(4.0)*(float)G;
			
			}
			if(max<(-3.78)*(float)A+(-8.8)*(float)B+(-0.69)*(float)C+(9.2)*(float)D+(3.5)*(float)E+(2.7)*(float)F+(4.0)*(float)G)
			{
				max = (-3.78)*(float)A+(-8.8)*(float)B+(-0.69)*(float)C+(9.2)*(float)D+(3.5)*(float)E+(2.7)*(float)F+(4.0)*(float)G;

				bestx = count2;
				besty = y;
				bestrotate = count;
				
	
			}
			/*if(max == (-3.78) *(float)A+(-8.8)*(float)B+(-0.59)*(float)C+(8.2)*(float)D+(3.7)*(float)E+(2.5)*(float)F+(4.0)*(float)G)
			{
				if(Fflag == 1)
				{
					if(bestx !=0 )
					bestx -= 1;
				}
				if(besty < y)
				{
					
					bestx = count2;
					bestrotate = count;
				}
			
						
			}*/
		}
	}
	y=0;
	while(CheckToMove(field,nextBlock[0],bestrotate,++y,bestx));
	--y;
	score+=AddBlockToField(field,nextBlock[0],bestrotate,y,bestx);
	score+=DeleteLine(field);
	PrintScore(score);
	DrawField();
	nextBlock[0] = nextBlock[1];
	nextBlock[1] = nextBlock[2];
	nextBlock[2] = rand()%7;
	DrawNextBlock(nextBlock);
	DrawBlockWithFeatures(blockY,blockX,nextBlock[0],blockRotate);

	
}
timed_out = 0;

}
void recommendedPlay(){

	int command;
	clear();
	act.sa_handler = genetic;/* 고쳐야할 함수 */;
	
	sigaction(SIGALRM,&act,&oact);
	InitTetris();
	do{
		if(timed_out == 0){
			alarm(1);
			timed_out = 1;
		}
		command = GetCommand();
		if(ProcessCommand(command) == QUIT){
			alarm(0);
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-bye!!");
			refresh();
			getch();
			return;
		}
	}while(!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2, WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	// user code
}

void DrawBlockWithFeatures(int y, int x, int blockID, int blockRotate)
{
	DrawBlock(y,x,blockID,blockRotate,' ');
	DrawShadow(y,x,blockID,blockRotate);
	DrawRecommend(y,x,blockID,blockRotate);
}
