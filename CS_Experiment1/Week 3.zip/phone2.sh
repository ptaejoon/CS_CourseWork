if [ $# -eq 0 ]
then
	echo Usage: phone searchfor [...searchfor]
	echo "(You didn't tell me what you want to search for.)"
else
	count=1	
	for arg in $*
	do
		if [ $count == 1 ]
		then
			egrep -i $arg mydata > string
			count=2	
		else
			egrep -i $arg string > string2
			cat string2 > string
			rm string2
			
		fi
			 	
	done
	
	d="awk -f display.awk"
	cat string|$d
	rm string

fi
