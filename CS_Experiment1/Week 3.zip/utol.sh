echo "working directory:"
read a	

if [ -z $a ]
then
	
	for b in *
	do
		c=$(echo $b | tr "a-zA-Z" "A-Za-z")
		if [ $b != $c ]
		then
			mv $b $c
		fi
	done
else
	if [ -d $a ]
	then
		
		cd $a
		for b in *
		do
			c=$(echo $b | tr "a-zA-Z" "A-Za-z")
			if [ $b != $c ]
			then
				mv $b $c
			fi
		done
		
	else
		echo "요청하신 파일이 존재하지 않습니다."
	fi	
fi 



