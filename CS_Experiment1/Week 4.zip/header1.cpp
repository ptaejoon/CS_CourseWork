#include "Headerfile.h"

void counting(int numbers[],int inputs)
{
	int count;
	for(count = 1; count <= inputs; count++)
	{
		if(count < 10)
		{
			numbers[count]++;
		}
		else if(count < 100)
		{
			numbers[count%10]++;
			numbers[count/10]++;
		}
		else
		{
			numbers[count/100]++;
			numbers[count%10]++;
			numbers[(count/10)%10]++;
		}
	}
}
