
#include <stdio.h>
#include <stdlib.h>

void SaveNumbers(int** SavedNumbers,int n,int numbers[]);
void initialization(int numbers[]);
void counting(int numbers[], int inputs);
