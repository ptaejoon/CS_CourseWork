#include<stdio.h>
#include<stdlib.h>
#include"Headerfile.h"
int main()
{
	int n,count,count2;
	int numbers[10]={0};
	int *inputs;
	int **SavedNumbers;
	scanf("%d",&n);

	inputs = (int *)malloc(sizeof(int)*n);
	SavedNumbers = (int **)malloc(sizeof(int*)*n);
	for(count = 0; count < n; count++)
	{
		SavedNumbers[count] = (int *)malloc(sizeof(int)*10);
	}
	for(count = 0; count < n; count++)
	{
		scanf("%d",&inputs[count]);
	}
	for(count = 0; count < n; count++)
	{
		counting(numbers,inputs[count]);
		SaveNumbers(SavedNumbers,count,numbers);
		initialization(numbers);
	}
	for(count = 0; count < n; count++)
	{
		for(count2 = 0; count2 < 10; count2++)
		{
			printf("%d ",SavedNumbers[count][count2]);
		}
		printf("\n");
	}
	free(inputs);
	for(count = 0; count < n; count++)
	{
		free(SavedNumbers[count]);
	}
	free(SavedNumbers);
}	
