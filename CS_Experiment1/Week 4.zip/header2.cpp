#include "Headerfile.h"

void SaveNumbers(int** SavedNumbers,int n,int numbers[])
{
	int count;
	for(count = 0; count < 10; count++)
	{
		SavedNumbers[n][count] = numbers[count];
	}
}
void initialization(int numbers[])
{
	int count;
	for(count = 0; count < 10; count++)
	{
		numbers[count] = 0;
	}
}
