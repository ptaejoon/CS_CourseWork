#define MAX_SIZE 50
#include<stdio.h>
#include<stdlib.h>
typedef enum {head,entry} tagfield;
typedef struct matrix_node *matrix_pointer;
typedef struct entry_node {
	int row;
	int col;
	int value;
}entry_node;

typedef struct matrix_node{
	matrix_pointer down;
	matrix_pointer right;
	tagfield tag;
	union{
		matrix_pointer next;
		entry_node entry;
	}u;
}matrix_node;
matrix_pointer hdnode[MAX_SIZE];
matrix_pointer mread(FILE *fp)
{
	int num_rows,num_cols,num_terms=0,num_heads,i,j;
	int row, col, value, current_row;
	matrix_pointer temp, last, node;
	fscanf(fp,"%d %d",&num_rows, &num_cols);

	num_heads = (num_cols > num_rows) ? num_cols : num_rows;
	node = (matrix_node *)malloc(sizeof(matrix_node));
	node->tag = entry;
	node->u.entry.row = num_rows;
	node->u.entry.col = num_cols;
	if(!num_heads)node->right = node;
	else
	{
		for(i=0;i<num_heads; i++)
		{
			
			temp = (matrix_node *)malloc(sizeof(matrix_node));
			hdnode[i] = temp;
			hdnode[i]->tag = head;
			hdnode[i]->right = temp;
			hdnode[i]->u.next = temp;
		}
		current_row = 0;
		last = hdnode[0];
		for(i=0; i<num_rows; i++)
		{
			for(j=0;j<num_cols;j++)
			{
				fscanf(fp,"%d ",&value);
				if(value == 0)
					continue;
				else{
					row = i;
					col = j;
				}
				if(row > current_row)
				{
					last->right = hdnode[current_row];
					current_row = row; last = hdnode[row];
				}
				temp = (matrix_node *)malloc(sizeof(matrix_node));
				temp -> tag = entry;
				temp->u.entry.row = row;
				temp->u.entry.col = col;
				temp->u.entry.value = value;
				last->right = temp;
				last = temp;
				hdnode[col]->u.next->down=temp;
				hdnode[col]->u.next=temp;
			}
		}
		last->right = hdnode[current_row];
		for(i=0; i<num_cols; i++)
			hdnode[i] ->u.next->down = hdnode[i];
		for(i=0; i<num_heads-1; i++)
			hdnode[i]->u.next = hdnode[i+1];
		hdnode[num_heads-1]->u.next = node;
		node->right = hdnode[0];
	}
	return node;
}
void mwrite(matrix_pointer a)
{
	int i;
	if(a == NULL)
	{
		printf("Empty!");
		return;
	}
	matrix_pointer temp=a->right;
    matrix_pointer head = a->right;

	for(i=0;i<a->u.entry.row;i++)
	{
		for(temp=head->right;temp != head; temp = temp->right)
			printf("%d %d %d\n",temp->u.entry.row, temp->u.entry.col,temp->u.entry.value);
		head= head->u.next;
	}
}
void merase(matrix_pointer *a)
{
	int i,num_heads;
	matrix_pointer x = (*a)->right;
	matrix_pointer y = (*a)->right;
	matrix_pointer head = (*a)->right;
	for(i=0;i<(*a)->u.entry.row; i++)
	{
		y=head->right;
		while(y != head){
			x=y; y=y->right; free(x);
		}
		x= head;
		head = head->u.next; free(x);
	}
	y = head;
	while (y != *a)
	{
		x=y;
		y = y->u.next;
		free(x);
	}
	free(*a);
	*a = NULL;
}
matrix_pointer madd(matrix_pointer a, matrix_pointer b)
{
	if(a->u.entry.row != b->u.entry.row || a->u.entry.col != b->u.entry.col)
	{
		printf("Cannot be added!\n");
		return NULL;
	}
	int a_num_heads,b_num_heads,d_num_heads;
	int i,current_row,row=0,col;
	int aflag=0, bflag=0;
	a_num_heads = (a->u.entry.row > a->u.entry.col) ? a->u.entry.row : a->u.entry.col;
	matrix_pointer d;
	matrix_pointer temp,last;
	matrix_pointer atemp,btemp;
	d = (matrix_node *)malloc(sizeof(matrix_node));
	d->tag = entry;
	d->u.entry.row = a->u.entry.row;
	d->u.entry.col = a->u.entry.col;
	d_num_heads = a_num_heads;

	atemp = a->right->right;
	btemp = b->right->right;
	if(!d_num_heads)d->right = d;
	else
	{
		for(i=0; i<d_num_heads; i++)
		{
			temp = (matrix_node *)malloc(sizeof(matrix_node));
			hdnode[i] = temp;
			hdnode[i]->tag = head;
			hdnode[i]->right = temp;
			hdnode[i]->u.next = temp;

		}
		current_row = 0;
		last = hdnode[0];
		while(row < d->u.entry.row)
		{
			if (atemp->tag == head )
			{
				if (btemp->tag== head)
				{
					aflag = 0;
					bflag = 0;
					row++;
					atemp = atemp->u.next->right;
					btemp = btemp->u.next->right;
					continue;
				}
		
				aflag = 1;
		
				
				
			}
			if (btemp->tag == head)
			{
				if (atemp->tag == head)
				{
					aflag = 0;
					bflag = 0;
					row++;
					atemp = atemp->u.next;
					btemp = btemp->u.next;
					continue;
				}
	
				bflag = 1;
		
			}
			
			if(btemp == b)
			{
				//b만 쭉 써주기
				temp = (matrix_node *)malloc(sizeof(matrix_node));
			//	row = atemp->u.entry.row;
				col = atemp->u.entry.col;
				
				if(row > current_row)
				{
					last->right = hdnode[current_row];
					current_row = row;
					last = hdnode[row];
				}
				temp->tag = entry;
				temp->u.entry.row = row;
				temp->u.entry.col = col;
				temp->u.entry.value = atemp->u.entry.value;
				last->right = temp;
				last = temp;
				hdnode[col]->u.next->down=temp;
				hdnode[col]->u.next = temp;
				atemp = atemp->right;
				continue;
			}
			else if(atemp == a)
			{
				//a만 쭉 써주기
				temp = (matrix_node *)malloc(sizeof(matrix_node));
			//	row = btemp->u.entry.row;
				col = btemp->u.entry.col;
				if(row > current_row)
				{
					last->right = hdnode[current_row];
					current_row = row;
					last = hdnode[row];
				}
				temp -> tag = entry;
				temp -> u.entry.row = row;
				temp -> u.entry.col = col;
				temp -> u.entry.value = btemp->u.entry.value;
				last->right = temp;
				last = temp;
				hdnode[col]->u.next = temp;
				btemp = btemp->right;
				continue;
			}
			else
			{
				temp = (matrix_node *)malloc(sizeof(matrix_node));
				if (atemp->u.entry.row > btemp->u.entry.row)
				{
					// b 넣어줘야함
					//			row = btemp->u.entry.row;
					col = btemp->u.entry.col;
					if (row > current_row)
					{
						last->right = hdnode[current_row];
						current_row = row;
						last = hdnode[row];
					}
					temp->tag = entry;
					temp->u.entry.row = row;
					temp->u.entry.col = col;
					temp->u.entry.value = btemp->u.entry.value;
					last->right = temp;
					last = temp;
					hdnode[col]->u.next = temp;
					btemp = btemp->right;
					continue;

				}
				else if (atemp->u.entry.row < btemp->u.entry.row)
				{
					//a
					//				row = atemp->u.entry.row;
					col = atemp->u.entry.col;
					if (row > current_row)
					{
						last->right = hdnode[current_row];
						current_row = row;
						last = hdnode[row];
					}
					temp->tag = entry;
					temp->u.entry.row = row;
					temp->u.entry.col = col;
					temp->u.entry.value = atemp->u.entry.value;
					last->right = temp;
					last = temp;
					hdnode[col]->u.next = temp;
					atemp = atemp->right;
					continue;
				}
				else
				{
					if (atemp->u.entry.col > btemp->u.entry.col || aflag == 1)
					{//b
						//					row = btemp->u.entry.row;
						if (bflag == 1)continue;
						col = btemp->u.entry.col;
						if (row > current_row)
						{
							last->right = hdnode[current_row];
							current_row = row;
							last = hdnode[row];
						}
						temp->tag = entry;
						temp->u.entry.row = row;
						temp->u.entry.col = col;
						temp->u.entry.value = btemp->u.entry.value;
						last->right = temp;
						last = temp;
						hdnode[col]->u.next = temp;
						btemp = btemp->right;
						continue;
					}
					else if (atemp->u.entry.col < btemp->u.entry.col || bflag == 1)
					{//a
						//					row = atemp->u.entry.row;
						if (aflag == 1)continue;
						col = atemp->u.entry.col;
						if (row > current_row)
						{
							last->right = hdnode[current_row];
							current_row = row;
							last = hdnode[row];
						}
						temp->tag = entry;
						temp->u.entry.row = row;
						temp->u.entry.col = col;
						temp->u.entry.value = atemp->u.entry.value;
						last->right = temp;
						last = temp;
						hdnode[col]->u.next = temp;
						atemp = atemp->right;
						continue;
					}
					else{
						// 더하기

						//				row = atemp->u.entry.row;
						col = atemp->u.entry.col;
						if (atemp->u.entry.value + btemp->u.entry.value == 0)
						{
							atemp = atemp->right;
							btemp = btemp->right;
							continue;
						}
						if (row > current_row)
						{
							last->right = hdnode[current_row];
							current_row = row;
							last = hdnode[row];
						}
						temp->tag = entry;
						temp->u.entry.row = row;
						temp->u.entry.col = col;
						temp->u.entry.value = atemp->u.entry.value + btemp->u.entry.value;;
						last->right = temp;
						last = temp;
						hdnode[col]->u.next = temp;
						atemp = atemp->right;
						btemp = btemp->right;
						continue;

					}
				}
			}
			
		}
		last->right = hdnode[current_row];
		for (i = 0; i < d->u.entry.col; i++)
		{
			hdnode[i]->u.next->down = hdnode[i];
		}
		for (i = 0; i < d_num_heads - 1; i++)
		{
			hdnode[i]->u.next = hdnode[i + 1];
		}
		hdnode[d_num_heads-1]->u.next = d;
		d->right = hdnode[0];

	}
	return d;
	

}

matrix_pointer mmult(matrix_pointer a, matrix_pointer b)
{
	if(a->u.entry.col != b->u.entry.row)
	{
		printf("Cannot be multiplied!\n");
		return NULL;
	}
	int d_num_heads;
	int i, current_row, row = 0, col;
	int aflag = 0, bflag = 0;
	d_num_heads = (a->u.entry.row > b->u.entry.col) ? a->u.entry.row : b->u.entry.col;
	matrix_pointer d;
	matrix_pointer temp, last;
	matrix_pointer atemp, btemp;
	d = (matrix_node *)malloc(sizeof(matrix_node));
	d->tag = entry;
	d->u.entry.row = a->u.entry.row;
	d->u.entry.col = b->u.entry.col;
	atemp = a->right->right;
	btemp = b->right->down;
	if (!d_num_heads)d->right = d;
	else
	{
		for (i = 0; i<d_num_heads; i++)
		{
			temp = (matrix_node *)malloc(sizeof(matrix_node));
			hdnode[i] = temp;
			hdnode[i]->tag = head;
			hdnode[i]->right = temp;
			hdnode[i]->u.next = temp;
		}
		current_row = 0;
		last = hdnode[0];
		while
		{
		}

		last->right = hdnode[current_row];
		for (i = 0; i < d->u.entry.col; i++)
		{
			hdnode[i]->u.next->down = hdnode[i];
		}
		for (i = 0; i < d_num_heads - 1; i++)
		{
			hdnode[i]->u.next = hdnode[i + 1];
		}
		hdnode[d_num_heads - 1]->u.next = d;
		d->right = hdnode[0];

	}
	return d;


}
void main()
{
	matrix_pointer a,b,d;
	FILE * afp;
	FILE * bfp;
	afp=fopen("A.txt","r");
	bfp=fopen("B.txt","r");
	a = mread(afp);
	b = mread(bfp);

	mwrite(a);
	mwrite(b);


	d = madd(a,b);
	mwrite(d);
	merase(&d);
	/*
	d = mmult(a,b);
	mwrite(d);
	merase(&d);
	*/
	merase(&a);
	merase(&b);
	mwrite(a);
	mwrite(b);
	mwrite(d);

	fclose(afp);
	fclose(bfp);
}

