#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#define MAX_TERMS 101
typedef struct {
	int row;
	int col;
	int value;
}TERM;

void readMatrix(FILE* fp, TERM *A) {
	int i, j, k = 0;
	A[0].value = 0;
	//Read rows and columns of matrix from file
	fscanf(fp,"%d %d",&(A[0].row),&(A[0].col));
	for (i = 0; i < A[0].row; i++) {
		for (j = 0; j < A[0].col; j++) {
			//Get each element
			fscanf(fp,"%d",&k);	
			if (k != 0) {		
				//Store it in the right place
				A[0].value++;
				A[A[0].value].row = i;
				A[A[0].value].col = j;
				A[A[0].value].value = k;
			}
		}
	}
}
void printMatrix(TERM* A) {
	int i, j;
	for (i = 0; i <= A[0].value; i++) {
		//Print with given format
		printf("%d | %d | %d\n",A[i].row,A[i].col,A[i].value);
	}
}

void fastTranspose(TERM* A, TERM* B) {
	int rowTerms[MAX_TERMS];
	int startingPos[MAX_TERMS];
	int i, j;
	//Put modified row, column and value information of A into B
	B[0].row = A[0].col;
	B[0].col = A[0].row;
	B[0].value = A[0].value;

	for (i = 0; i < A[0].col; i++)rowTerms[i] = 0;
		//First loop: Initialize rowTerms

	for (i = 1; i <= A[0].value; i++)rowTerms[A[i].col]++;
		//Second loop: Count the number of specific row's element

	startingPos[0] = 1;
	for (i = 1; i <= A[0].col; i++)
	{
		startingPos[i] = startingPos[i-1] + rowTerms[i-1];	
	}
	//Third loop: Set the startingPos(which implies starting position of each row's element)
	//Use startingPos and rowTerms of last row 

	for (i = 1; i <= A[0].value; i++) {
		j = startingPos[A[i].col]++;
		B[j].row = A[i].col;
		B[j].col = A[i].row;
		B[j].value = A[i].value;
	//Put exact values into matrix B following matrix A's information

	}
}
void storeSum(TERM* A, int *cnt, int row, int col, int *val) {
	if (*val != 0) {
		*cnt += 1;
	
		A[*cnt].row = row;
		A[*cnt].col = col;
		A[*cnt].value = *val;
		//Store final summ[ation value into matrix
		//also initialize summation value
	}
	*val = 0;
}

void mmult(TERM* A, TERM* B, TERM* C) {
	TERM tB[MAX_TERMS];
	int i, j;
	int row, col, rowBegin = 1;
	//row, col: current row and column
	//rowBegin: element index starting new row value
	//cntC:    number of elements from multiplication
	//sum:     current accumulated value
	int cntC = 0, sum = 0;
	row = A[1].row;
	if(A[0].col != B[0].row)
	{
		printf("Incompatible matrices\n");
		return;
	}
	fastTranspose(B, tB);
	A[A[0].value+1].row = A[0].row;
	tB[B[0].value+1].row = B[0].col;
	tB[B[0].value+1].col = -1;
	//Transpose for easy multiplication
	for (i = 1; i <= A[0].value;) {
		col = tB[1].row;
		
		for (j = 1; j <= B[0].value+1;) {
			if (A[i].row != row) {
				//store its summation value into C with current row and column
				//set next rowBegin element of A
				//set column information(col) with next element of tBi
				
				storeSum(C,&cntC,row,col,&sum);
				i=rowBegin;
				for( ; tB[j].row == col;j++);
				col = tB[j].row;
			}
			else if (tB[j].row != col) {
				storeSum(C,&cntC,row,col,&sum);
				i = rowBegin;
				col = tB[j].row;
				//store its summation value into C with current row and column
				//set next rowBegin element of A
				//set column information(col) with changed value


			}
			else {

				if (A[i].col == tB[j].col)
				{
					sum += (A[i++].value * tB[j++].value);
				}	

				else if (A[i].col<tB[j].col)
				{
					i++;
				}
					//increment index of A to compare next value
				else
				{
					j++;
				}
					//increment index of B to compare next value
			}
		}
		for( ; A[i].row == row; i++);
		rowBegin = i;
		row = A[i].row;
		//find and set next rowBegin element of A
		//set row information with changed value



	}
	//Store row, column and number of elements in C
	C[0].row = A[0].row;
	C[0].col = B[0].col;
	C[0].value = cntC;


}

void main() {
	TERM termA[MAX_TERMS], termB[MAX_TERMS], termC[MAX_TERMS];
	FILE *fp1 = NULL, *fp2 = NULL;
	fp1 = fopen("A.txt", "r");
	fp2 = fopen("B.txt", "r");

	readMatrix(fp1, termA);
	
	readMatrix(fp2, termB);
	mmult(termA, termB, termC);
	printMatrix(termC);
	fclose(fp1);
	fclose(fp2);
}


