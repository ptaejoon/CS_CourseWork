#include <stdio.h>
#include<stdlib.h>
#define MAX_EXPR_SIZE 100
typedef enum {
	lparen,rparen,plus,minus,times,divide,mod,eos,operand}precedence;


int top = -1;
int isp[] = {0,19,12,12,13,13,13,0};
int icp[] = {20,19,12,12,13,13,13,0};
typedef struct _node{
	precedence operator; 
	struct _node* link;
}node;
node* head;
char str[MAX_EXPR_SIZE];
precedence getToken(char a)
{
	switch(a){
		case '(':
			return lparen;
		case ')':
			return rparen;
		case '+':
			return plus;
		case'-':
			return minus;
		case'/':
			return divide;
		case'*':
			return times;
		case'%':
			return mod; 
		case'\0':
			return eos;
		default: return operand;
	}
}
void rExpr(FILE *fp)
{
	fscanf(fp,"%s",str);
}
void push(precedence a)
{
	node* end=head;
	if(head == NULL)
	{
		head = (node *)malloc(sizeof(node));
		head->operator = a;
		head->link = NULL;
	}
	else
	{
		
		while(end -> link != NULL){
			end = end->link;
		}	
		end->link = (node *)malloc(sizeof(node));
		end=end->link;
		end->operator = a;
		end->link = NULL;
			
	}
}
void pop()
{
	node* end1;
	node* end2;
	end1 = head;
	if(head == NULL)
	{
		return;
	}
	end2 = head;
	while(end1->link != NULL)
	{
		end2 = end1;
		end1 = end1->link;
	}
	

	switch(end1->operator){
		case plus:
			printf("+");
			break;
		case minus:
			printf("-");
			break;
		case times:
			printf("*");
			break;
		case mod:
			printf("%%");
			break;
		case divide:
			printf("/");
			break;
	}
	end2->link = NULL;
	free(end1);
}
void postfix()
{
	int count,count2;
	node *ptr;
	ptr = head;
	node *l;
	int lnum=0;
	for(count = 0; str[count]!='\0'; count++)
	{
		if(getToken(str[count]) == operand)
		{
			printf("%c",str[count]);
		}

		else
		{
			switch(str[count])
			{
				case '(':
					push(lparen);
					ptr = head;
					break;

				case ')':
					while(ptr->link != NULL)
					{
						if(ptr->operator == lparen)
						{
							l=ptr;
						}
						ptr = ptr->link;
					}
					while(l->link != NULL)
					{
						lnum++;
						l=l->link;
					}
					for(count2=0; count2<lnum;count2++)
					{
						pop();
					}
					lnum = 0;
					ptr = head;
					l = head;		
					break;
				case '+':
					while(ptr->link != NULL)
					{
						ptr = ptr->link;
					}
					while (ptr != NULL && isp[ptr->operator] >= icp[plus])
						pop();

					push(plus);
					ptr = head;
					break;
				case '-':
					while(ptr->link != NULL)
					{
						ptr = ptr->link;
					}
					while (ptr != NULL && isp[ptr->operator] >= icp[minus])
						pop();
					push(minus);
					ptr = head;
					break;
				case '*':
					while(ptr->link != NULL)
					{
						ptr = ptr->link;
					}
					while (ptr != NULL && isp[ptr->operator] >= icp[times])
						pop();

					push(times);
					ptr = head;
					break;
				case '/':
					while(ptr->link != NULL)
					{
						ptr = ptr->link;
					}
					while (ptr != NULL && isp[ptr->operator] >= icp[divide])
						pop();

					push(divide);
					ptr = head;
					break;
				case '%':
					while(ptr->link != NULL)
					{
						ptr = ptr->link;
					}
					while(ptr != NULL && isp[ptr->operator] >= icp[mod])
						pop();
					push(mod);
					ptr = head;
					break;
			}
		}
	}
	
	while (head->link != NULL)
	{
		pop();
	}
	printf("\n");

}
void main()
{
	FILE* fp;
	fp = fopen("expr.txt","r");
	rExpr(fp);
	postfix();
	fclose(fp);
}
