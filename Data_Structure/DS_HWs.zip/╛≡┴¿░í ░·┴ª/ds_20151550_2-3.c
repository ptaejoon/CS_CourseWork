#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 24
#define TRUE 1
#define FALSE 0
typedef struct _node *sptr;
typedef struct _node
{
	int data;
	sptr link;
} Node;
void push(Node** head,int value)
{
	Node* nownode = *head;
	Node* newnode;
	newnode =(Node *)malloc(sizeof(Node));
	newnode->data = value;
	newnode->link = *head;
	if (nownode == NULL)
	{
		(*head) = newnode;
		return;
	}
	(*head) = newnode;
	return;
}
int pop(Node** head)
{
	Node* nownode = *head;
	Node* temp;
	int tempo;
	if (nownode == NULL)
	{
		return;
	}
	temp = (*head);
	tempo = ((*head)->data);
	(*head) = (*head)->link;
	free(temp);
	return tempo;
}
void main()
{
	int out[MAX_SIZE];
	sptr seq[MAX_SIZE];
	sptr x[MAX_SIZE],y,top;
	int i,j,n,k;

	printf("Enter the size (<= %d)\n",MAX_SIZE);
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		out[i] = TRUE;
		seq[i] = NULL;
		x[i] = NULL;
	}
	printf("Enter a pair of numbers (-1 -1 to quit): ");
	scanf("%d%d",&i,&j);
	while(i >= 0)
	{
		push(i+x,j);
		push(j+x,i);
		printf("Enter a pair of numbers (-1 -1 to quit): ");
		scanf("%d %d",&i,&j);
	}

	for(i=0; i<n ; i++)
	{
		if(out[i])
		{
			printf("\nNew clas: %5d",i);
			out[i] = FALSE;
			y = x[i];
			top = NULL;
			for( ; ; )
			{
				while(y)
				{
					j = y->data;
					if(out[j])
					{
						printf("%5d",j);
						out[j]=FALSE;
						push(&top,pop(&y));
					}
					else
					{
						pop(&y);
					}
				}
				if(!top)
				{
					break;
				}
				y = x[pop(&top)];
			}
		}
	}
	printf("\n");
}
