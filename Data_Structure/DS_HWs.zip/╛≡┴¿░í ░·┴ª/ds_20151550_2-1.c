#include<stdio.h>
#include<stdlib.h>
typedef struct node* sptr;
typedef struct node{
	int data;
	sptr link;
}Node;
sptr head;
void main()
{
	FILE *fp;
	int command;
	int num;
	int count;
	sptr top;
	sptr temp;
	fp = fopen("data.txt","r");
	while(fscanf(fp,"%d %d",&command,&num) != EOF)
	{
		if(command == 0)
		{
			temp = (sptr)malloc(sizeof(Node));
			if(head == NULL)
			{
				temp->data = num;
				temp->link = NULL;
				head = temp;
				top = head;
			}
			else
			{
				temp->data = num;
				temp->link = head;
				head = temp;
				top = temp;
			
			}
		}
		if(command == 1)
		{
			if(head == NULL)
			{
				continue;
			}
			else
			{
				head=head->link;
				free(top);
			}
		}
	}
	temp = head;
	
	for(temp; temp->link != NULL; temp=temp->link)
	{
		printf("%d ",temp->data);
	
	}
	printf("%d\n",temp->data);
	
	temp = head;
	while(temp->link != NULL)
	{
		temp=head;
		head = head->link;
		free(head);
	}
	free(head);

	fclose(fp);
}
			
