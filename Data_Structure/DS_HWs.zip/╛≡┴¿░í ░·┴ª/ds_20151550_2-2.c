#include<stdio.h>
#include<stdlib.h>
typedef struct node* sptr;
typedef struct node{
	int data;
	sptr link;
}Node;
sptr head;
void main()
{
	FILE *fp;
	int command;
	int num;
	int count;
	sptr front;
	sptr rear;
	sptr temp;
	fp = fopen("data.txt","r");
	while(fscanf(fp,"%d %d",&command,&num) != EOF)
	{
		if(command == 0)
		{
			temp = (sptr)malloc(sizeof(Node));
			if(head == NULL)
			{
				temp->data = num;
				temp->link = NULL;
				head = temp;
				front = head;
				rear = head;
			}
			else
			{
				temp->data = num;
				temp->link = NULL;
				rear->link = temp;
				rear=temp; 
			
			}
		}
		if(command == 1)
		{
			if(head == NULL)
			{
				continue;
			}
			else
			{
				head = front->link;
				free(front);
				front = head;
			}
		}
	}
	temp = front;
	
	for(temp; temp->link != NULL; temp=temp->link)
	{
		printf("%d ",temp->data);
	
	}
	printf("%d\n",temp->data);
	
	temp = head;
	while(temp->link != NULL)
	{
		temp=head;
		head = head->link;
		free(head);
	}
	free(head);

	fclose(fp);
}
			
