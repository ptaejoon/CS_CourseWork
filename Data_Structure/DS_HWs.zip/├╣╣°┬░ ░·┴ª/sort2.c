#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main()
{
	int n;
	FILE *fp;
	int *U;
	int count;
	int temp;
	int count2;
	int num1,num2;
	double duration;
	int step =10;
	for(count2 = 0; count2<1000;count2 += step)
	{
	long repetitions = 0;
	clock_t start = clock();
	do{
		repetitions++;
	fp=fopen("lab1.data","r");
	fscanf(fp,"%d",&n);
	U=(int*)malloc(sizeof(int)*n);
	for(count = 0; count < n; count++)
	{
		fscanf(fp,"%d",U+count);
	}
	fclose(fp);
	
	
	for(count=0; count<n-1; count++)
	{
		num1 = count;
		num2 = num1+1;
		temp = U[num2];
		for(num1;num1>=0;num1--)
		{
			if(U[num1]>temp)
			{	
				U[num1+1]=U[num1];
			}
			else
			{
				break;
			}
		}
		U[num1+1]=temp;
			
	}
	free(U);
	}while(repetitions != 10000);
	clock_t stop = clock();
	 duration = ((double)(stop-start))/CLOCKS_PER_SEC;
	 printf("%ld %lf\n",repetitions,duration);
	if(count2 == 100) step = 100;	
}
	
	
}
